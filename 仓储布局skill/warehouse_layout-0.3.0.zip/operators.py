"""操作器：面板按钮与 MCP 一行调用共用。
每个操作器都把结果摘要写进 scene["wh_last_result"]（JSON 字符串），便于脚本/MCP 读取，不必再写验证代码。

MCP 调用示例：
    bpy.ops.wh.to_xyz(collection="G12_G13_横梁货架", prefix="横梁货架", group_mode='LINE')
    bpy.ops.wh.to_points(collection="G05_双链式输送机", prefix="输送线", group_mode='LINE')
    bpy.ops.wh.align_heights(margin=1.0)
    bpy.ops.wh.validate(); print(bpy.context.scene["wh_last_report"])
    bpy.ops.wh.import_underlay(config_path="/…/project-config.json")
    bpy.ops.wh.compare_mode()
    bpy.ops.wh.build_walls(config_path="/…/project-config.json", height=6.0)
"""
import json

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, StringProperty

from .core import architecture, assets, build, nodes, stats, underlay, prefs


def _sources(context, collection, names):
    if names:
        return [bpy.data.objects[n] for n in names.split(",") if n.strip() in bpy.data.objects]
    if collection:
        c = bpy.data.collections.get(collection)
        return list(c.all_objects) if c else []
    return list(context.selected_objects)


def _target(context, collection, sources):
    if collection and collection in bpy.data.collections:
        return bpy.data.collections[collection]
    if sources and sources[0].users_collection:
        return sources[0].users_collection[0]
    return context.scene.collection


def _store(context, res):
    def clean(v):
        if isinstance(v, (list, tuple)):
            return [clean(x) for x in v]
        if isinstance(v, dict):
            return {k: clean(x) for k, x in v.items()}
        return v if isinstance(v, (int, float, str, bool, type(None))) else str(v)
    context.scene["wh_last_result"] = json.dumps(clean(res), ensure_ascii=False)


SRC_PROPS = dict(
    collection=StringProperty(name="集合", description="源集合名（留空则用选中对象）", default=""),
    object_names=StringProperty(name="对象名", description="逗号分隔的对象名（优先于集合）", default=""),
    keep_source=BoolProperty(name="保留源对象(隐藏)", default=False),
)


class WH_OT_setup_nodes(bpy.types.Operator):
    bl_idname = "wh.setup_nodes"
    bl_label = "注册节点组为资产"
    bl_description = "创建/重建 GN_XYZ阵列 与 GN_点位实例 节点组，并标记为资产（可在资产浏览器拖用）"
    bl_options = {'REGISTER', 'UNDO'}
    rebuild: BoolProperty(name="重建", default=False)

    def execute(self, context):
        for ng in (nodes.ensure_xyz_group(self.rebuild), nodes.ensure_point_group(self.rebuild)):
            if not ng.asset_data:
                ng.asset_mark()
            ng.asset_data.description = "仓储布局工具"
        self.report({'INFO'}, "节点组已就绪：GN_XYZ阵列、GN_点位实例")
        _store(context, dict(ok=True))
        return {'FINISHED'}


class WH_OT_to_xyz(bpy.types.Operator):
    bl_idname = "wh.to_xyz"
    bl_label = "转为 XYZ 阵列"
    bl_description = "把集合实例空对象或点位对象自动分解为按 X/Y/Z 设数量与间距的阵列；校验一致才替换，否则回滚"
    bl_options = {'REGISTER', 'UNDO'}
    collection: SRC_PROPS['collection']
    object_names: SRC_PROPS['object_names']
    keep_source: SRC_PROPS['keep_source']
    prefix: StringProperty(name="名称前缀", default="阵列")
    group_mode: EnumProperty(name="父级分组", items=[
        ('CLUSTER', "连通区块", "占地相连的阵列挂同一父级（地堆区块）"),
        ('LINE', "同一排/列", "同一排/列的各段挂同一父级（货架）"),
        ('NONE', "不分组", "")], default='CLUSTER')
    merge_y: BoolProperty(name="合并相邻行(Y)", description="背靠背/相邻行合成 Y 数量>1", default=True)
    max_dy: FloatProperty(name="Y 合并最大间距", default=1.6, min=0.0, unit='LENGTH')
    max_dx: FloatProperty(name="X 连续最大间距", default=3.2, min=0.1, unit='LENGTH')
    gap: FloatProperty(name="区块连通间隙", default=0.5, min=0.0, unit='LENGTH')

    def execute(self, context):
        src = _sources(context, self.collection, self.object_names)
        if not src:
            self.report({'ERROR'}, "没有源对象"); return {'CANCELLED'}
        res = build.to_xyz(src, _target(context, self.collection, src), self.prefix, self.merge_y, self.group_mode,
                           self.gap, self.max_dx, self.max_dy, self.keep_source)
        _store(context, res)
        msg = f"{res['msg']}：单元 {res.get('units', 0)} → 阵列 {res.get('arrays', 0)}（{res.get('groups', 0)} 组）"
        if res.get('skipped'):
            msg += f"；跳过 {len(res['skipped'])} 个不支持的对象"
        self.report({'INFO'} if res['ok'] else {'ERROR'}, msg)
        return {'FINISHED'} if res['ok'] else {'CANCELLED'}


class WH_OT_to_points(bpy.types.Operator):
    bl_idname = "wh.to_points"
    bl_label = "转为点位对象"
    bl_description = "把集合实例空对象转为点位几何节点对象（可混合多种资产）；按直线输送线自动分组"
    bl_options = {'REGISTER', 'UNDO'}
    collection: SRC_PROPS['collection']
    object_names: SRC_PROPS['object_names']
    keep_source: SRC_PROPS['keep_source']
    prefix: StringProperty(name="名称前缀", default="输送线")
    group_mode: EnumProperty(name="分组", items=[('LINE', "按直线分线", ""), ('ONE', "合成一个", "")], default='LINE')

    def execute(self, context):
        src = _sources(context, self.collection, self.object_names)
        if not src:
            self.report({'ERROR'}, "没有源对象"); return {'CANCELLED'}
        res = build.to_points(src, _target(context, self.collection, src), self.prefix, self.group_mode, self.keep_source)
        _store(context, res)
        self.report({'INFO'} if res['ok'] else {'ERROR'}, f"{res['msg']}：{res.get('units', 0)} 个 → {res.get('objects', 0)} 个对象")
        return {'FINISHED'} if res['ok'] else {'CANCELLED'}


class WH_OT_align_heights(bpy.types.Operator):
    bl_idname = "wh.align_heights"
    bl_label = "高度对齐"
    bl_description = "提升机顶 = 货架顶 + 余量；堆垛机顶 = 货架顶（货架顶从场景自动识别）"
    bl_options = {'REGISTER', 'UNDO'}
    collection: SRC_PROPS['collection']
    object_names: SRC_PROPS['object_names']
    margin: FloatProperty(name="提升机高出", default=-1.0, description="<0 时用偏好设置里的默认值", unit='LENGTH')
    include_stackers: BoolProperty(name="同时对齐堆垛机", default=True)
    all_scene: BoolProperty(name="整个场景", default=True)

    def execute(self, context):
        p = prefs()
        margin = self.margin if self.margin >= 0 else (p.hoist_margin if p else 1.0)
        objs = list(context.scene.objects) if self.all_scene and not (self.collection or self.object_names) \
            else _sources(context, self.collection, self.object_names)
        res = stats.align_heights(objs, margin, self.include_stackers)
        _store(context, res)
        self.report({'INFO'} if res['ok'] else {'ERROR'}, res['msg'])
        return {'FINISHED'} if res['ok'] else {'CANCELLED'}


class WH_OT_validate(bpy.types.Operator):
    bl_idname = "wh.validate"
    bl_label = "验收报告"
    bl_description = "按资产/类型计数，检查提升机高于货架、堆垛机≈货架顶、堆垛机与货架干涉；结果写入文本「WH_验收报告」"
    bl_options = {'REGISTER'}
    collection: StringProperty(name="集合", description="只检查该集合（留空=整个场景）", default="")
    json_path: StringProperty(name="JSON 输出", subtype='FILE_PATH', default="")

    def execute(self, context):
        scope = None
        if self.collection:
            c = bpy.data.collections.get(self.collection)
            scope = list(c.all_objects) if c else []
        p = prefs()
        rng = (p.hoist_margin_min, p.hoist_margin_max) if p else (0.3, 2.0)
        res = stats.validate(scope, rng)
        if self.json_path:
            stats.dump_json(res, self.json_path)
        _store(context, res['data'])
        self.report({'INFO'} if res['ok'] else {'WARNING'}, res['summary'])
        return {'FINISHED'}


class WH_OT_import_underlay(bpy.types.Operator):
    bl_idname = "wh.import_underlay"
    bl_label = "导入平面底图"
    bl_description = "按 project-config.json 的 DXF、区域、原点、单位和图层规则，把平面图按图层导入为矢量底图（z=-0.01，不可选中）"
    bl_options = {'REGISTER', 'UNDO'}
    config_path: StringProperty(name="项目配置文件", description="project-config.json：记录图纸路径、原点、单位、底图区域和排除图层", subtype='FILE_PATH', default="")
    dxf_path: StringProperty(name="替换图纸（可选）", description="留空则用配置里的 DXF；只在图纸出了新版本、坐标不变时填写", subtype='FILE_PATH', default="")
    include_text: BoolProperty(name="包含文字/标注", default=False)
    replace: BoolProperty(name="替换同名底图", default=True)

    def invoke(self, context, event):
        if not self.config_path:
            self.config_path = context.scene.get("wh_config_path", "")
        return context.window_manager.invoke_props_dialog(self, width=560)

    def draw(self, context):
        L = self.layout
        L.prop(self, "config_path", text="项目配置文件（project-config.json）")
        c = L.column(align=True); c.scale_y = 0.8
        c.label(text="必填。记录用哪张图纸、原点和单位、导入哪块区域；与模型共用坐标，保证对位。", icon='INFO')
        L.separator()
        L.prop(self, "dxf_path", text="替换图纸（可选）")
        c = L.column(align=True); c.scale_y = 0.8
        c.label(text="通常留空，用配置里的图纸。图纸出了新版本（坐标未挪动）时再选新 DXF。", icon='INFO')
        L.separator()
        r = L.row(); r.prop(self, "include_text"); r.prop(self, "replace")

    def execute(self, context):
        path = self.config_path or context.scene.get("wh_config_path", "")
        if not path:
            self.report({'ERROR'}, "请指定 project-config.json"); return {'CANCELLED'}
        try:
            cfg = underlay.load_config(path)
        except Exception as ex:
            self.report({'ERROR'}, f"读取配置失败：{ex}"); return {'CANCELLED'}
        if self.dxf_path:
            cfg["dxf"] = self.dxf_path
        if self.include_text:
            cfg["include_text"] = True
        if not cfg.get("dxf"):
            self.report({'ERROR'}, "配置里没有 dxf 路径"); return {'CANCELLED'}
        wm = context.window_manager
        try:
            wm.progress_begin(0, 100)
            res = underlay.import_underlay(cfg, self.replace)
        except ImportError:
            self.report({'ERROR'}, "缺少 ezdxf（插件 wheels 未加载）"); return {'CANCELLED'}
        finally:
            wm.progress_end()
        context.scene["wh_config_path"] = path
        _store(context, res)
        self.report({'INFO'} if res['ok'] else {'ERROR'}, res['msg'])
        return {'FINISHED'} if res['ok'] else {'CANCELLED'}


class WH_OT_compare_mode(bpy.types.Operator):
    bl_idname = "wh.compare_mode"
    bl_label = "对照模式"
    bl_description = "切换：顶视正交、模型半透明、底图按图层颜色显示；再次点击恢复原视图"
    bl_options = {'REGISTER'}
    xray_alpha: FloatProperty(name="模型透明度", default=0.4, min=0.0, max=1.0)

    def execute(self, context):
        on = underlay.compare_mode(context, None, self.xray_alpha)
        self.report({'INFO'}, "对照模式：开" if on else "对照模式：关")
        return {'FINISHED'}


class WH_OT_build_walls(bpy.types.Operator):
    bl_idname = "wh.build_walls"
    bl_label = "一键挤出墙体"
    bl_description = "从底图的墙/门窗/柱图层识别墙段与空间，按空间生成墙体对象（几何节点挤出，高度可调）和柱子"
    bl_options = {'REGISTER', 'UNDO'}
    config_path: StringProperty(name="项目配置文件", subtype='FILE_PATH', default="")
    height: FloatProperty(name="墙高", default=0.0, min=0.0, description="0 = 用配置 walls.height（未填则 6m）", unit='LENGTH')
    column_height: FloatProperty(name="柱高", default=0.0, min=0.0, description="0 = 同墙高", unit='LENGTH')
    replace: BoolProperty(name="替换已生成的墙体", default=True)

    def invoke(self, context, event):
        if not self.config_path:
            self.config_path = context.scene.get("wh_config_path", "")
        return context.window_manager.invoke_props_dialog(self, width=520)

    def execute(self, context):
        path = self.config_path or context.scene.get("wh_config_path", "")
        if not path:
            self.report({'ERROR'}, "请指定 project-config.json"); return {'CANCELLED'}
        try:
            ucfg = underlay.load_config(path); wc = architecture.wall_config(path)
        except Exception as ex:
            self.report({'ERROR'}, f"读取配置失败：{ex}"); return {'CANCELLED'}
        res = architecture.build_walls(ucfg, wc, self.height, self.column_height, self.replace)
        context.scene["wh_config_path"] = path
        _store(context, res)
        self.report({'INFO'} if res['ok'] else {'ERROR'}, res['msg'])
        return {'FINISHED'} if res['ok'] else {'CANCELLED'}


class WH_OT_clear_cache(bpy.types.Operator):
    bl_idname = "wh.clear_cache"
    bl_label = "清除资产尺寸缓存"
    bl_options = {'REGISTER'}

    def execute(self, context):
        assets.clear_cache()
        return {'FINISHED'}


classes = (WH_OT_import_underlay, WH_OT_compare_mode, WH_OT_build_walls, WH_OT_setup_nodes, WH_OT_to_xyz, WH_OT_to_points, WH_OT_align_heights, WH_OT_validate, WH_OT_clear_cache)
