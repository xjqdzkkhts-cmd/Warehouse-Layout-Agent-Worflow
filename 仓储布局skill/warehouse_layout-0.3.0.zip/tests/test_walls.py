"""纯 Python 测试：python3 tests/test_walls.py
造一栋 20×10m、墙厚 0.2m 的房子，中间一道隔墙分成两间，隔墙上开门（门扇线+门弧用直线段近似封口）。"""
import importlib.util, math, os
spec = importlib.util.spec_from_file_location("walls", os.path.join(os.path.dirname(__file__), "..", "core", "walls.py"))
W = importlib.util.module_from_spec(spec); spec.loader.exec_module(W)

def rect(x0, y0, x1, y1, c="wall"):
    p = [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
    return [(p[i], p[(i + 1) % 4], c) for i in range(4)]

S = rect(0, 0, 20, 10) + rect(0.2, 0.2, 19.8, 9.8)           # 外墙双线
# 隔墙 x=10±0.1，y 0.2→4 与 5→9.8，中间 1m 门洞
S += [((9.9, 0.2), (9.9, 4), "wall"), ((10.1, 0.2), (10.1, 4), "wall"), ((9.9, 4), (10.1, 4), "wall"),
      ((9.9, 5), (9.9, 9.8), "wall"), ((10.1, 5), (10.1, 9.8), "wall"), ((9.9, 5), (10.1, 5), "wall")]
# 门：门扇 + 门弧（折线近似）封住门洞
S += [((10.0, 4), (11.0, 4), "open")]
arc = [(10 + math.cos(a), 4 + math.sin(a)) for a in [i * math.pi / 2 / 8 for i in range(9)]]
S += [(arc[i], arc[i + 1], "open") for i in range(8)]
S += [((10.0, 5), (10.0, 4), "open")]
# 柱子（独立小方框）
S += rect(5, 5, 5.4, 5.4, "col")

R = W.build(S)
rooms = sorted(R["rooms"], key=lambda i: -R["faces"][i]["area"])
areas = [round(R["faces"][i]["area"], 1) for i in rooms]
assert len(rooms) == 2 and all(88 <= a <= 96 for a in areas), areas
kinds = R["kinds"]
assert kinds.count("column") == 1, kinds.count("column")
walls = [fi for fi, k in enumerate(kinds) if k == "wall"]
assert len(walls) >= 6, len(walls)                              # 外墙在隔墙接头处被横切成多段
assign = R["assign"]
per_room = {r: sum(1 for fi in walls if assign.get(fi) == r) for r in rooms}
assert all(n >= 2 for n in per_room.values()), per_room          # 两间都分到墙
assert sum(1 for fi in walls if assign.get(fi) is None) == 0
print("walls tests ok", areas, per_room)
