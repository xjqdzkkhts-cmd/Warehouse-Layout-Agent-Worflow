"""后台 Blender 回归测试（只读，不保存）：
Blender -b <项目.blend> --python tests/test_blender.py
需要项目文件里已有：G01 立库 XYZ 阵列、G08 提升机空对象、G02 堆垛机空对象、产线_输送线 点位对象。
"""
import math
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))
import bpy
import warehouse_layout as W

W.register()
from warehouse_layout.core import assets, nodes, stats, build

ok_all = True


def check(name, cond, detail=""):
    global ok_all
    ok_all &= bool(cond)
    print(("PASS " if cond else "FAIL ") + name + (f"  {detail}" if detail else ""))


S = bpy.context.scene
# 1) 节点组注册
bpy.ops.wh.setup_nodes()
check("节点组为资产", all(bpy.data.node_groups[n].asset_data for n in (nodes.XYZ_GN, nodes.POINT_GN)))

# 2) 验收（原样）
bpy.ops.wh.validate()
rep = S["wh_last_report"]
print(rep)
check("验收-提升机规则通过", "[PASS] 提升机高于货架" in rep)
check("验收-无干涉", "[PASS] 堆垛机与货架干涉" in rep)
check("验收-每巷道一台", "[PASS] 每巷道一台堆垛机" in rep)
check("验收-护栏覆盖轨道", "[PASS] 护栏覆盖轨道端部" in rep)

# 3) 高度对齐：先把提升机压回原高，再对齐
for o in bpy.data.collections["G08_提升机"].objects:
    o.scale.z = 1.0
bpy.ops.wh.align_heights(margin=1.0)
tops = [u['hi'][2] for u in stats.units() if u['type'] == 'hoist']
check("对齐-提升机顶=21", tops and all(abs(t - 21.0) < 0.01 for t in tops), str([round(t, 3) for t in tops]))

# 4) 点位 → 空对象（造源）→ to_points 按线
lines = [o for o in bpy.data.collections["产线_输送线"].objects if nodes.kind(o) == 'point']
before = stats.instance_stats(lines)
ga = assets.group_assets()
tmpc = bpy.data.collections.new("__测试_空对象"); S.collection.children.link(tmpc)
n_emp = 0
for o in lines:
    me = o.data; n = len(me.vertices)
    sz = [0.0] * (3 * n); asz = [0.0] * (3 * n); rt = [0.0] * (3 * n); ix = [0] * n
    me.attributes["size"].data.foreach_get("vector", sz); me.attributes["asize"].data.foreach_get("vector", asz)
    me.attributes["rot"].data.foreach_get("vector", rt); me.attributes["idx"].data.foreach_get("value", ix)
    for i, v in enumerate(me.vertices):
        e = bpy.data.objects.new(f"E{n_emp:04d}", None); e.instance_type = 'COLLECTION'; e.instance_collection = ga[ix[i]]
        e.location = o.matrix_world @ v.co; e.rotation_euler = (0, 0, rt[3 * i + 2])
        e.scale = (sz[3 * i] / asz[3 * i], sz[3 * i + 1] / asz[3 * i + 1], sz[3 * i + 2] / asz[3 * i + 2])
        tmpc.objects.link(e); n_emp += 1
for o in lines:
    bpy.data.objects.remove(o)
bpy.context.view_layer.update()
r = bpy.ops.wh.to_points(collection=tmpc.name, prefix="线", group_mode='LINE')
new = [o for o in tmpc.objects if nodes.kind(o) == 'point']
after = stats.instance_stats(new)
check("to_points-实例一致", stats.same_stats(before, after), f"{before[0]}→{after[0]}")
check("to_points-分线数", len(new) == 25, f"{len(new)} 条（期望 25）")

# 5) 点位 → XYZ：站台托盘（点位对象）
src = bpy.data.objects.get("立库出入口托盘")
if src:
    b = stats.instance_stats([src])
    bpy.ops.wh.to_xyz(object_names=src.name, prefix="站台托盘", group_mode='CLUSTER')
    new = [o for o in bpy.data.objects if o.name.startswith("站台托盘") and nodes.kind(o) == 'xyz']
    check("to_xyz(点位)-实例一致", stats.same_stats(b, stats.instance_stats(new)), f"{len(new)} 个阵列")

# 6) 空对象 → XYZ：造背靠背两列货架（带缺口），按排/列分组
rack = assets.asset_collection("横梁货架")
tc = bpy.data.collections.new("__测试_货架"); S.collection.children.link(tc)
info = assets.asset_info(rack)
k = 0
for x in (300.0, 301.3):
    for y, L in [(0, 2.48), (2.39, 2.48), (4.78, 2.48), (7.17, 2.48), (8.966, 1.288), (14.342, 2.48), (16.732, 2.48)]:
        e = bpy.data.objects.new(f"R{k:03d}", None); e.instance_type = 'COLLECTION'; e.instance_collection = rack
        e.location = (x, y, 0); e.rotation_euler = (0, 0, math.pi / 2)
        e.scale = (L / info['size'][0], 1.01 / info['size'][1], 1.0)
        tc.objects.link(e); k += 1
b = stats.instance_stats(list(tc.objects))
bpy.ops.wh.to_xyz(collection=tc.name, prefix="测试货架", group_mode='LINE')
arr = [o for o in tc.objects if nodes.kind(o) == 'xyz']
par = [o for o in tc.objects if o.type == 'EMPTY' and not o.instance_collection]
check("to_xyz(空对象)-实例一致", stats.same_stats(b, stats.instance_stats(arr)), f"{b[0]}")
check("to_xyz(空对象)-3段Y=2、1个父级",
      sorted((nodes.get_params(o, nodes.XYZ_MOD)["X数量"], nodes.get_params(o, nodes.XYZ_MOD)["Y数量"]) for o in arr) == [(1, 2), (2, 2), (4, 2)] and len(par) == 1,
      str(sorted((nodes.get_params(o, nodes.XYZ_MOD)["X数量"], nodes.get_params(o, nodes.XYZ_MOD)["Y数量"]) for o in arr)))
# 参数响应
o = max(arr, key=lambda o: nodes.get_params(o, nodes.XYZ_MOD)["X数量"])
n0 = stats.instance_stats([o])[0]
nodes.set_params(o, nodes.XYZ_MOD, X数量=5); bpy.context.view_layer.update()
check("XYZ 参数响应", stats.instance_stats([o])[0] == n0 * 5 // 4, f"{n0}→{stats.instance_stats([o])[0]}")

# 7) 平面底图（插件自带 wheels；配置复制到临时目录，强制完整解析）
import json, shutil, tempfile, time
cfg_src = os.environ.get("WH_TEST_CONFIG", "")
if cfg_src:
    tmpd = tempfile.mkdtemp(); cfg = os.path.join(tmpd, "project-config.json"); shutil.copy(cfg_src, cfg)
    for o in [o for o in bpy.data.objects if o.get("wh_底图")]:
        bpy.data.objects.remove(o)
    t = time.time(); bpy.ops.wh.import_underlay(config_path=cfg); t1 = time.time() - t
    und = [o for o in bpy.data.objects if o.get("wh_底图")]
    check("底图-导入", len(und) >= 5 and sum(len(o.data.edges) for o in und) > 1000,
          f"{len(und)} 层 {sum(len(o.data.edges) for o in und)} 线段 {t1:.1f}s")
    import sys as _s
    check("底图-ezdxf 来自插件 wheels", any(p.endswith(".whl") and "ezdxf" in p for p in _s.path))
    t = time.time(); bpy.ops.wh.import_underlay(config_path=cfg); t2 = time.time() - t
    n_before = len(und)
    und = [o for o in bpy.data.objects if o.get("wh_底图")]
    check("底图-缓存重导入", t2 < 5 and len(und) == n_before, f"{t2:.2f}s")
    # 对位：底图“托盘（新）”层范围应与输送线模型范围重合
    lay = next((o for o in und if o["图层"] == "托盘（新）"), None)
    if lay:
        xs = [v.co.x for v in lay.data.vertices]; ys = [v.co.y for v in lay.data.vertices]
        n, lo, hi = stats.instance_stats([o for o in bpy.data.objects if nodes.kind(o) == 'point' and "线" in o.name])
        check("底图-与输送线对位", abs(min(xs) - lo[0]) < 0.3 and abs(max(ys) - hi[1]) < 0.3,
              f"底图 x0={min(xs):.2f} y1={max(ys):.2f} / 模型 x0={lo[0]:.2f} y1={hi[1]:.2f}")
    # 一键挤出墙体（复用底图缓存）
    bpy.ops.wh.build_walls(config_path=cfg, height=7.0)
    wc = bpy.data.collections.get("墙体_1F")
    wobs = list(wc.objects) if wc else []
    check("墙体-按空间分对象", len(wobs) >= 20, f"{len(wobs)} 个墙体对象")
    if wobs:
        top = max(stats.instance_stats([]) and 0 or 0, max((o.evaluated_get(bpy.context.evaluated_depsgraph_get()).bound_box[1][2] for o in wobs), default=0))
        check("墙体-高度参数", abs(top - 7.0) < 0.01, f"墙顶 {top:.2f}m")
        o = wobs[0]; m = o.modifiers["墙体挤出"]
        ids = {s.name: s.identifier for s in m.node_group.interface.items_tree if s.in_out == 'INPUT'}
        m[ids["高度"]] = 9.0; o.update_tag(); bpy.context.view_layer.update()
        top2 = o.evaluated_get(bpy.context.evaluated_depsgraph_get()).bound_box[1][2]
        check("墙体-改高度生效", abs(top2 - 9.0) < 0.01, f"{top2:.2f}m")
    shutil.rmtree(tmpd, ignore_errors=True)

# 8) 最终验收仍通过
bpy.ops.wh.validate()
print(S["wh_last_report"].splitlines()[0])
print("ALL OK" if ok_all else "SOME FAILED")
