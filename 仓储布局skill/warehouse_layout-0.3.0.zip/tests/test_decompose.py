"""纯 Python 测试：python3 tests/test_decompose.py"""
import math, os, sys, importlib.util
spec = importlib.util.spec_from_file_location("decompose", os.path.join(os.path.dirname(__file__), "..", "core", "decompose.py"))
d = importlib.util.module_from_spec(spec); spec.loader.exec_module(d)

def U(x, y, ux=2.48, uy=1.0, rz=0.0, bottom=0.0, uz=3.744, asset="横梁货架"):
    return dict(asset=asset, cx=x, cy=y, bottom=bottom, rz=rz, ux=ux, uy=uy, uz=uz)

# 1) 背靠背两列(沿世界Y排列, rz=90°)，中间有缺口和一个单托位 → 3 段，每段 Y=2
rz = math.pi / 2
col = [0, 2.39, 4.78, 7.17]
units = []
for x in (10.0, 11.3):
    units += [U(x, y, rz=rz) for y in col] + [U(x, 8.966, ux=1.288, rz=rz)] + [U(x, y, rz=rz) for y in (14.342, 16.732)]
A = d.plan_arrays(units)
assert sum(a['nx'] * a['ny'] * a['nz'] for a in A) == len(units)
assert sorted((a['nx'], a['ny']) for a in A) == [(1, 2), (2, 2), (4, 2)], [(a['nx'], a['ny']) for a in A]
G = d.group_arrays(A, "LINE")
assert len(G) == 1, G
# 2) 立库一排：39 格 × 5 节竖向叠放
units = [U(1.0 + i * 2.35, 30.0, ux=2.35, uy=1.2, uz=4.0, bottom=k * 4.0) for i in range(39) for k in range(5)]
A = d.plan_arrays(units)
assert len(A) == 1 and (A[0]['nx'], A[0]['ny'], A[0]['nz'], round(A[0]['dz'], 3)) == (39, 1, 5, 4.0), A
# 3) L 形地堆：3x2 + 1 → 2 个矩形，1 个区块
units = [U(x * 1.3, y * 1.1, 1.2, 1.0, uz=0.863, asset="托盘") for x in range(3) for y in range(2)] + [U(0, 2.2, 1.2, 1.0, uz=0.863, asset="托盘")]
A = d.plan_arrays(units)
assert len(A) == 2 and len(d.group_arrays(A, "CLUSTER")) == 1
# 4) 相隔巷道(2.7m)的两排不合并
units = [U(i * 2.35, 0, 2.35, 1.2) for i in range(5)] + [U(i * 2.35, 2.7, 2.35, 1.2) for i in range(5)]
assert len(d.plan_arrays(units)) == 2
# 5) 输送线分组：一条横线 + 一条被横线打断的纵线 + 一个零散件
boxes = [(x, 10, 2.4, 1.3) for x in (0, 2.4, 4.8)] + [(7, y, 1.35, 1.4) for y in (4, 5.4, 12, 13.4)] + [(9.5, 10.5, 1.6, 0.4)]
L = d.group_lines(boxes)
assert sorted(len(g[1]) for g in L) == [3, 5], L  # 零散件离纵线更近
print("decompose tests ok")
