"""DXF 平面底图：按图层导入为只含边的网格（矢量，任意缩放都清晰），与模型共用 project-config 的原点和单位。
另含“对照模式”：顶视正交 + 模型半透明 + 底图按对象颜色显示。"""
import glob
import hashlib
import json
import os
import sys

import bpy
from mathutils import Quaternion, Vector

COLL_NAME = "DXF底图"
TEXT_TYPES = {"TEXT", "MTEXT", "ATTRIB", "ATTDEF"}
UNIT_SCALE = {1: 0.0254, 2: 0.3048, 4: 0.001, 5: 0.01, 6: 1.0, 14: 0.1}
UNIT_NAME = {"mm": 0.001, "cm": 0.01, "m": 1.0, "in": 0.0254}


def ensure_ezdxf():
    try:
        import ezdxf  # noqa: F401
    except ImportError:
        here = os.path.join(os.path.dirname(os.path.dirname(__file__)), "wheels")
        for whl in sorted(glob.glob(os.path.join(here, "*.whl"))):
            if whl not in sys.path:
                sys.path.append(whl)
        import ezdxf  # noqa: F401
    import ezdxf
    return ezdxf


def load_config(path):
    with open(bpy.path.abspath(path), encoding="utf-8") as f:
        c = json.load(f)
    u = c.get("underlay") or {}
    origin = c.get("origin_dxf_mm") or c.get("origin_dxf") or [0, 0]
    return dict(
        dxf=u.get("dxf") or c.get("dxf"),
        units=c.get("dxf_units"),
        origin=origin,
        region=u.get("region_dxf"),
        exclude_layers=set(u.get("exclude_layers", [])),
        include_layers=set(u.get("include_layers", [])),
        include_text=bool(u.get("include_text", False)),
        include_hatch=bool(u.get("include_hatch", False)),
        flatten_m=float(u.get("flatten_m", 0.03)),
        cache_dir=os.path.dirname(bpy.path.abspath(path)),
        z=float(u.get("z", -0.01)),
        name=u.get("name", "1F"),
    )


def _key_points(doc, e, bc):
    """区域筛选用的关键点（比 ezdxf 精确包围盒快约 30 倍）：块按定义缓存局部范围，插入时变换 4 个角点。"""
    t = e.dxftype(); d = e.dxf
    if t == "LINE":
        return [d.start, d.end]
    if t == "LWPOLYLINE":
        return [(p[0], p[1]) for p in e.get_points("xy")]
    if t == "POLYLINE":
        return [v.dxf.location for v in e.vertices]
    if t in ("CIRCLE", "ARC"):
        c, r = d.center, d.radius
        return [(c.x - r, c.y - r), (c.x + r, c.y + r)]
    if t == "ELLIPSE":
        c = d.center; r = d.major_axis.magnitude
        return [(c.x - r, c.y - r), (c.x + r, c.y + r)]
    if t == "SPLINE":
        return list(e.control_points) or list(e.fit_points)
    if t in ("TEXT", "MTEXT", "ATTDEF", "ATTRIB"):
        return [d.insert]
    if t == "POINT":
        return [d.location]
    if t in ("SOLID", "TRACE", "3DFACE"):
        return [d.vtx0, d.vtx1, d.vtx2]
    if t == "INSERT":
        name = d.name
        if name not in bc:
            bc[name] = None
            xs, ys = [], []
            for be in doc.blocks.get(name):
                try:
                    for p in _key_points(doc, be, bc):
                        xs.append(p[0]); ys.append(p[1])
                except Exception:
                    pass
            bc[name] = (min(xs), min(ys), max(xs), max(ys)) if xs else None
        lb = bc[name]
        if lb is None:
            return []
        m = e.matrix44()
        return [m.transform((x, y, 0)) for x in (lb[0], lb[2]) for y in (lb[1], lb[3])]
    from ezdxf import bbox
    b = bbox.extents([e], fast=True)
    return [b.extmin, b.extmax] if b.has_data else []


def _walk(doc, e, region, parent_layer, bc, depth=0):
    """递归区域筛选：整体在区域内 → 整体保留；跨区域的块 → 拆开逐个判断（例如绑定进来的整栋建筑外部参照）。
    产出 (图层, 实体)。块内 0 图层继承父级图层。"""
    try:
        P = _key_points(doc, e, bc)
    except Exception:
        return
    if not P:
        return
    xs = [p[0] for p in P]; ys = [p[1] for p in P]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    lay = e.dxf.layer
    if lay == "0" and parent_layer:
        lay = parent_layer
    if region is None:
        yield lay, e
        return
    if x1 < region[0] or x0 > region[1] or y1 < region[2] or y0 > region[3]:
        return
    inside = x0 >= region[0] and x1 <= region[1] and y0 >= region[2] and y1 <= region[3]
    if e.dxftype() == "INSERT" and not inside and depth < 8:
        try:
            for ve in e.virtual_entities():
                yield from _walk(doc, ve, region, lay, bc, depth + 1)
        except Exception:
            pass
        return
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    if inside or (region[0] <= cx <= region[1] and region[2] <= cy <= region[3]):
        yield lay, e


def _walk_all(doc, msp, region, bc):
    for e in msp:
        yield from _walk(doc, e, region, None, bc)


def layer_display(name):
    """外部参照绑定图层 'AX-01-Plan.dwg-2025…$0$J-WALL' → 'J-WALL'"""
    return name.split("$")[-1]


def _cache_path(cfg):
    path = bpy.path.abspath(cfg["dxf"])
    st = os.stat(path)
    sig = json.dumps(["v2", path, st.st_size, int(st.st_mtime), cfg.get("units"), list(cfg["origin"]), cfg.get("region"),
                      sorted(cfg["exclude_layers"]), sorted(cfg["include_layers"]), cfg["include_text"],
                      cfg["include_hatch"], cfg["flatten_m"]], ensure_ascii=False)
    h = hashlib.md5(sig.encode()).hexdigest()[:12]
    d = cfg.get("cache_dir") or bpy.app.tempdir
    return os.path.join(d, f".wh_underlay_{cfg['name']}_{h}.npz")


def _aci_rgb(ezdxf, aci):
    from ezdxf import colors
    if aci in (7, 0, 256, None) or aci < 1:
        return (0.85, 0.85, 0.85)
    r, g, b = colors.aci2rgb(abs(aci))
    return (r / 255, g / 255, b / 255)


def extract(cfg, progress=None):
    """解析 DXF → {图层: (verts[N,3], edges[M,2], rgb)}；结果按 DXF/配置签名缓存为 .npz。"""
    import numpy as np
    cp = _cache_path(cfg)
    if os.path.exists(cp):
        z = np.load(cp, allow_pickle=False)
        layers = json.loads(str(z["layers"]))
        return {lay: (z[f"v{i}"], z[f"e{i}"], tuple(z[f"c{i}"])) for i, lay in enumerate(layers)}, True
    ezdxf = ensure_ezdxf()
    from ezdxf import disassemble
    path = bpy.path.abspath(cfg["dxf"])
    doc = ezdxf.readfile(path)
    msp = doc.modelspace()
    s = UNIT_NAME.get(str(cfg.get("units") or "").lower()) or UNIT_SCALE.get(doc.header.get("$INSUNITS", 4), 0.001)
    ox, oy = cfg["origin"]
    region = cfg.get("region")
    flat = cfg["flatten_m"] / s
    excl, incl = cfg["exclude_layers"], cfg["include_layers"]

    data = {}  # layer -> (verts, edges)
    bc = {}
    n_ent = 0
    for raw, e in _walk_all(doc, msp, region, bc):
        lay = layer_display(raw)
        if raw in excl or lay in excl or (incl and lay not in incl and raw not in incl):
            continue
        t = e.dxftype()
        if (t in TEXT_TYPES or t == "DIMENSION") and not cfg["include_text"]:
            continue
        if t == "HATCH" and not cfg["include_hatch"]:
            continue
        n_ent += 1
        verts, edges = data.setdefault(lay, ([], []))
        try:
            prims = disassemble.to_primitives(disassemble.recursive_decompose([e]), max_flattening_distance=flat)
        except Exception:
            continue
        for p in prims:
            pt = p.entity.dxftype() if p.entity is not None else ""
            if (pt in TEXT_TYPES or pt == "DIMENSION") and not cfg["include_text"]:
                continue
            if pt == "HATCH" and not cfg["include_hatch"]:
                continue
            try:
                if p.path is not None and len(p.path):
                    subs = p.path.sub_paths() if p.path.has_sub_paths else [p.path]
                    for sp in subs:
                        pts = list(sp.flattening(flat))
                        if len(pts) < 2:
                            continue
                        i0 = len(verts)
                        verts.extend(((v.x - ox) * s, (v.y - oy) * s, 0.0) for v in pts)
                        edges.extend((i0 + k, i0 + k + 1) for k in range(len(pts) - 1))
                elif p.mesh is not None:
                    mv = p.mesh.vertices
                    i0 = len(verts)
                    verts.extend(((v.x - ox) * s, (v.y - oy) * s, 0.0) for v in mv)
                    seen = set()
                    for f in p.mesh.faces:
                        for a, b2 in zip(f, list(f[1:]) + [f[0]]):
                            k = (min(a, b2), max(a, b2))
                            if k not in seen:
                                seen.add(k); edges.append((i0 + a, i0 + b2))
            except Exception:
                continue
        if progress and n_ent % 500 == 0:
            progress(n_ent)

    out = {}
    for lay, (verts, edges) in data.items():
        if not edges:
            continue
        try:
            L = doc.layers.get(lay) or next((l for l in doc.layers if layer_display(l.dxf.name) == lay), None)
            rgb = _aci_rgb(ezdxf, L.color)
        except Exception:
            rgb = (0.85, 0.85, 0.85)
        out[lay] = (np.asarray(verts, dtype=np.float32), np.asarray(edges, dtype=np.int32), rgb)
    layers = sorted(out)
    try:
        arrs = {"layers": np.array(json.dumps(layers, ensure_ascii=False))}
        for i, lay in enumerate(layers):
            arrs[f"v{i}"], arrs[f"e{i}"], arrs[f"c{i}"] = out[lay][0], out[lay][1], np.array(out[lay][2], dtype=np.float32)
        np.savez_compressed(cp, **arrs)
    except OSError:
        pass
    return out, False


def import_underlay(cfg, replace=True, progress=None):
    """返回 dict(ok, layers, edges, msg)。cfg 来自 load_config（也可手工给 dict）。"""
    data, cached = extract(cfg, progress)
    coll = bpy.data.collections.get(COLL_NAME)
    if coll is None:
        coll = bpy.data.collections.new(COLL_NAME)
        bpy.context.scene.collection.children.link(coll)
    prefix = f"底图{cfg['name']}_"
    if replace:
        for o in [o for o in coll.objects if o.name.startswith(prefix)]:
            me = o.data
            bpy.data.objects.remove(o)
            if me and me.users == 0:
                bpy.data.meshes.remove(me)
    total = 0
    made = []
    for lay, (verts, edges, rgb) in sorted(data.items()):
        me = bpy.data.meshes.new(prefix + lay)
        me.vertices.add(len(verts)); me.vertices.foreach_set("co", verts.ravel())
        me.edges.add(len(edges)); me.edges.foreach_set("vertices", edges.ravel())
        me.update()
        ob = bpy.data.objects.new(prefix + lay, me)
        ob.location.z = cfg["z"]
        ob.color = (*rgb, 1.0)
        ob.hide_select = True
        ob["wh_底图"] = True; ob["图层"] = lay; ob["来源"] = bpy.path.abspath(cfg["dxf"])
        coll.objects.link(ob)
        total += len(edges); made.append(lay)
    return dict(ok=bool(made), layers=len(made), edges=total, cached=cached,
                msg=f"底图 {cfg['name']}：{len(made)} 个图层，{total} 条线段" + ("（读缓存）" if cached else ""))


def underlay_bounds():
    coll = bpy.data.collections.get(COLL_NAME)
    lo = Vector((1e9,) * 3); hi = -lo
    if coll:
        for o in coll.objects:
            if o.visible_get():
                for v in o.bound_box:
                    w = o.matrix_world @ Vector(v)
                    lo = Vector(map(min, lo, w)); hi = Vector(map(max, hi, w))
    return (lo, hi) if lo.x < hi.x else None


def compare_mode(context, enable=None, xray_alpha=0.4):
    """切换对照模式；enable=None 时取反。状态保存在 scene["wh_compare"]。"""
    sc = context.scene
    on = sc.get("wh_compare_on", False)
    enable = (not on) if enable is None else enable
    areas = [a for a in context.screen.areas if a.type == 'VIEW_3D'] if context.screen else []
    if enable:
        saved = []
        for a in areas:
            sp = a.spaces.active; r = sp.region_3d; sh = sp.shading
            saved.append(dict(persp=r.view_perspective, rot=list(r.view_rotation), loc=list(r.view_location), dist=r.view_distance,
                              stype=sh.type, xray=sh.show_xray, alpha=sh.xray_alpha, wct=sh.wireframe_color_type))
            sh.type = 'SOLID'; sh.show_xray = True; sh.xray_alpha = xray_alpha; sh.wireframe_color_type = 'OBJECT'
            r.view_perspective = 'ORTHO'; r.view_rotation = Quaternion((1, 0, 0, 0))
            bb = underlay_bounds()
            if bb:
                lo, hi = bb
                r.view_location = ((lo.x + hi.x) / 2, (lo.y + hi.y) / 2, 0)
                r.view_distance = max(hi.x - lo.x, hi.y - lo.y) * 0.75
        sc["wh_compare"] = json.dumps(saved)
        sc["wh_compare_on"] = True
    else:
        saved = json.loads(sc.get("wh_compare", "[]"))
        for a, s in zip(areas, saved):
            sp = a.spaces.active; r = sp.region_3d; sh = sp.shading
            r.view_perspective = s["persp"]; r.view_rotation = Quaternion(s["rot"]); r.view_location = s["loc"]; r.view_distance = s["dist"]
            sh.type = s["stype"]; sh.show_xray = s["xray"]; sh.xray_alpha = s["alpha"]; sh.wireframe_color_type = s["wct"]
        sc["wh_compare_on"] = False
    return enable
