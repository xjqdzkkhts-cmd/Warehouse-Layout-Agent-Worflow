"""纯 Python：单元 → XYZ 阵列 / 输送线分组。无 bpy 依赖，可单独测试（tests/test_decompose.py）。

单元 unit = dict(asset, cx, cy, bottom, rz, ux, uy, uz)：单元中心(世界XY)、底面高度、绕Z弧度、单元尺寸(资产局部轴)。
"""
import math
from collections import defaultdict


def _r(v, n=2):
    return round(v, n)


def _local(x, y, rz):
    c, s = math.cos(rz), math.sin(rz)
    return c * x + s * y, -s * x + c * y


def _world(lx, ly, rz):
    c, s = math.cos(rz), math.sin(rz)
    return c * lx - s * ly, s * lx + c * ly


def _even(vals, tol):
    if len(vals) < 2:
        return True
    d = vals[1] - vals[0]
    return all(abs((b - a) - d) < tol for a, b in zip(vals, vals[1:]))


def stack_columns(units, tol=0.02):
    """同一 XY 位置、等距竖向叠放的单元合成一柱：返回 [(代表单元, nz, dz)]。不等距时逐个保留。"""
    cols = defaultdict(list)
    for u in units:
        cols[(_r(u['cx'], 2), _r(u['cy'], 2))].append(u)
    out = []
    for us in cols.values():
        us.sort(key=lambda u: u['bottom'])
        zs = [u['bottom'] for u in us]
        if len(us) > 1 and _even(zs, tol):
            out.append((us[0], len(us), zs[1] - zs[0]))
        else:
            out += [(u, 1, u['uz']) for u in us]
    return out


def rectangles(pts, tol=0.03, max_dx=3.2, max_dy=1.6):
    """pts: [(lx, ly, key)]，key 相同才能同组。贪心分解成最大完整矩形 [(起点, nx, dx, ny, dy)]。"""
    left = set(pts)

    def find(x, y, key):
        for p in left:
            if p[2] == key and abs(p[0] - x) < tol and abs(p[1] - y) < tol:
                return p

    out = []
    while left:
        s = min(left, key=lambda p: (round(p[1], 2), p[0]))
        dx = min((p[0] - s[0] for p in left if p[2] == s[2] and abs(p[1] - s[1]) < tol and s[0] + tol < p[0] <= s[0] + max_dx), default=None)
        row = [s]
        if dx:
            while True:
                q = find(row[-1][0] + dx, s[1], s[2])
                if q:
                    row.append(q)
                else:
                    break
        dy = min((p[1] - s[1] for p in left if p[2] == s[2] and abs(p[0] - s[0]) < tol and s[1] + tol < p[1] <= s[1] + max_dy), default=None) if max_dy > 0 else None
        grid = [row]
        if dy:
            while True:
                nxt = [find(p[0], p[1] + dy * len(grid), s[2]) for p in row]
                if all(nxt):
                    grid.append(nxt)
                else:
                    break
        for r in grid:
            for p in r:
                left.discard(p)
        out.append((s, len(row), dx, len(grid), dy))
    return out


def plan_arrays(units, merge_y=True, max_dx=3.2, max_dy=1.6, tol=0.03):
    """单元 → 阵列参数列表。
    分组键：资产、朝向、单元尺寸、竖向叠放(nz,dz)、底面高度；组内在局部坐标系里分解矩形。"""
    groups = defaultdict(list)
    for u, nz, dz in stack_columns(units):
        rz = u['rz'] % (2 * math.pi)
        key = (u['asset'], _r(rz, 3), _r(u['ux']), _r(u['uy']), _r(u['uz']), nz, _r(dz, 3), _r(u['bottom']))
        groups[key].append(u)
    arrays = []
    for key, us in groups.items():
        asset, rz, ux, uy, uz, nz, dz, bottom = key
        pts = [(*_local(u['cx'], u['cy'], rz), 0) for u in us]
        for s, nx, dx, ny, dy in rectangles(pts, tol, max_dx, max_dy if merge_y else 0):
            ox, oy = _world(s[0], s[1], rz)
            arrays.append(dict(asset=asset, rz=rz, origin=(ox, oy), lx=s[0], ly=s[1],
                               nx=nx, dx=dx if dx else ux, ny=ny, dy=dy if dy else uy,
                               nz=nz, dz=dz if nz > 1 else uz, ux=ux, uy=uy, uz=uz, lift=bottom))
    return arrays


def array_footprint(a):
    """阵列世界 AABB (x0, y0, x1, y1)。"""
    corners = []
    for i in (0, a['nx'] - 1):
        for j in (0, a['ny'] - 1):
            lx = a['lx'] + i * a['dx']; ly = a['ly'] + j * a['dy']
            for sx in (-0.5, 0.5):
                for sy in (-0.5, 0.5):
                    corners.append(_world(lx + sx * a['ux'], ly + sy * a['uy'], a['rz']))
    xs = [c[0] for c in corners]; ys = [c[1] for c in corners]
    return min(xs), min(ys), max(xs), max(ys)


def _gap(a, b):
    return max(a[0] - b[2], b[0] - a[2], a[1] - b[3], b[1] - a[3])


def group_arrays(arrays, mode="CLUSTER", gap=0.5):
    """阵列分组（挂同一父级）：CLUSTER=占地连通；LINE=同组键且局部起始行相同（一排/一列的各段）；NONE=不分组。
    返回 [[阵列索引,...], ...]"""
    n = len(arrays)
    if mode == "NONE":
        return [[i] for i in range(n)]
    par = list(range(n))

    def f(i):
        while par[i] != i:
            par[i] = par[par[i]]; i = par[i]
        return i

    fps = [array_footprint(a) for a in arrays]
    for i in range(n):
        for j in range(i + 1, n):
            a, b = arrays[i], arrays[j]
            if mode == "LINE":
                ok = a['asset'] == b['asset'] and abs(a['rz'] - b['rz']) < 1e-3 and abs(a['ly'] - b['ly']) < 0.05
            else:
                ok = _gap(fps[i], fps[j]) < gap
            if ok:
                par[f(i)] = f(j)
    g = defaultdict(list)
    for i in range(n):
        g[f(i)].append(i)
    return sorted(g.values(), key=lambda idx: (min(fps[i][1] for i in idx), min(fps[i][0] for i in idx)))


def group_lines(boxes, row_tol=0.1, touch=0.3, small=2):
    """输送线分组。boxes: [(cx, cy, w, d)] 世界 AABB。
    1) 同 cy 且首尾相接的连成横线(≥2段)；2) 其余同 cx 合成纵线；3) ≤small 段的小组并入最近的大组。
    返回 [(方向'H'/'V', [索引...]), ...]"""
    n = len(boxes)

    def touching(i, j):
        a, b = boxes[i], boxes[j]
        return abs(a[0] - b[0]) - (a[2] + b[2]) / 2 < touch and abs(a[1] - b[1]) - (a[3] + b[3]) / 2 < touch

    def uf(items, same):
        par = {i: i for i in items}

        def f(x):
            while par[x] != x:
                par[x] = par[par[x]]; x = par[x]
            return x
        for i in items:
            for j in items:
                if i < j and same(i, j):
                    par[f(i)] = f(j)
        g = defaultdict(list)
        for i in items:
            g[f(i)].append(i)
        return list(g.values())

    H = [g for g in uf(range(n), lambda i, j: abs(boxes[i][1] - boxes[j][1]) < row_tol and touching(i, j)) if len(g) >= 2]
    used = {i for g in H for i in g}
    rest = [i for i in range(n) if i not in used]
    V = uf(rest, lambda i, j: abs(boxes[i][0] - boxes[j][0]) < row_tol)
    groups = [['H', g] for g in H] + [['V', g] for g in V]
    big = [g for g in groups if len(g[1]) > small]
    if not big:
        return [tuple(g) for g in groups]

    def dist(g1, g2):
        return min(max(abs(boxes[i][0] - boxes[j][0]) - (boxes[i][2] + boxes[j][2]) / 2,
                       abs(boxes[i][1] - boxes[j][1]) - (boxes[i][3] + boxes[j][3]) / 2) for i in g1 for j in g2)
    for g in groups:
        if len(g[1]) <= small:
            min(big, key=lambda b: dist(g[1], b[1]))[1].extend(g[1])
    return [tuple(g) for g in big]
