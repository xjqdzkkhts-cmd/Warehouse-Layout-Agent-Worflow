"""纯 Python：墙线网络 → 平面区域 → 墙段 / 空间 / 柱子，并把墙段按空间归属。无 bpy 依赖（tests/test_walls.py）。

输入 segments: [((x0, y0), (x1, y1), cls)]，cls ∈ {'wall', 'open', 'col'}，单位米。
流程：去重 → 交点打断 → 剪掉悬挂边 → 提取平面面（半边结构）→ 分类 → T 接头处横切墙带 → 重算 → 墙段归属空间。
"""
import math
from collections import defaultdict

CLS_RANK = {'wall': 0, 'col': 1, 'open': 2}


# ---------------- 打断与去重 ----------------

def _key(p, tol):
    return (round(p[0] / tol), round(p[1] / tol))


def node_segments(segs, tol=0.003, cell=2.0):
    """在交点/端点落在其他线段上的位置打断，返回 (V[(x,y)], E[(i,j,cls)])。"""
    segs = [(a, b, c) for a, b, c in segs if math.dist(a, b) > tol]
    grid = defaultdict(list)
    for i, (a, b, _) in enumerate(segs):
        x0, x1 = sorted((a[0], b[0])); y0, y1 = sorted((a[1], b[1]))
        for gx in range(int(math.floor(x0 / cell)), int(math.floor(x1 / cell)) + 1):
            for gy in range(int(math.floor(y0 / cell)), int(math.floor(y1 / cell)) + 1):
                grid[(gx, gy)].append(i)
    cuts = [[0.0, 1.0] for _ in segs]
    seen = set()
    for ids in grid.values():
        for ii in range(len(ids)):
            for jj in range(ii + 1, len(ids)):
                i, j = ids[ii], ids[jj]
                if (i, j) in seen:
                    continue
                seen.add((i, j))
                a, b, _ = segs[i]; c, d, _ = segs[j]
                rx, ry = b[0] - a[0], b[1] - a[1]; sx, sy = d[0] - c[0], d[1] - c[1]
                den = rx * sy - ry * sx
                la, lc = math.hypot(rx, ry), math.hypot(sx, sy)
                if abs(den) > 1e-12 * la * lc:
                    t = ((c[0] - a[0]) * sy - (c[1] - a[1]) * sx) / den
                    u = ((c[0] - a[0]) * ry - (c[1] - a[1]) * rx) / den
                    et, eu = tol / la, tol / lc
                    if -et <= t <= 1 + et and -eu <= u <= 1 + eu:
                        cuts[i].append(min(1.0, max(0.0, t))); cuts[j].append(min(1.0, max(0.0, u)))
                else:  # 平行：端点落在对方线段上
                    for (p, q, k, L) in ((c, d, i, la), (a, b, j, lc)):
                        base, (rx2, ry2) = (segs[k][0], (segs[k][1][0] - segs[k][0][0], segs[k][1][1] - segs[k][0][1]))
                        for pt in (p, q):
                            t = ((pt[0] - base[0]) * rx2 + (pt[1] - base[1]) * ry2) / (L * L)
                            if 0 < t < 1:
                                px, py = base[0] + t * rx2, base[1] + t * ry2
                                if math.hypot(px - pt[0], py - pt[1]) < tol:
                                    cuts[k].append(t)
    vid, V, E = {}, [], {}

    def v(p):
        k = _key(p, tol)
        if k not in vid:
            vid[k] = len(V); V.append(p)
        return vid[k]
    for (a, b, c), ts in zip(segs, cuts):
        ts = sorted(set(round(t, 9) for t in ts))
        pts = [(a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])) for t in ts]
        for p, q in zip(pts, pts[1:]):
            i, j = v(p), v(q)
            if i == j:
                continue
            k = (min(i, j), max(i, j))
            if k not in E or CLS_RANK[c] < CLS_RANK[E[k]]:
                E[k] = c
    return V, [(i, j, c) for (i, j), c in E.items()]


def prune_dangling(V, E):
    adj = defaultdict(set)
    for i, j, _ in E:
        adj[i].add(j); adj[j].add(i)
    stack = [k for k, s in adj.items() if len(s) == 1]
    while stack:
        k = stack.pop()
        if len(adj[k]) != 1:
            continue
        (n,) = adj[k]
        adj[k].clear(); adj[n].discard(k)
        if len(adj[n]) == 1:
            stack.append(n)
    keep = {(min(i, j), max(i, j)) for i in adj for j in adj[i]}
    return [(i, j, c) for i, j, c in E if (min(i, j), max(i, j)) in keep]


# ---------------- 平面面提取 ----------------

def _pip(pt, poly):
    x, y = pt; inside = False
    for (x0, y0), (x1, y1) in zip(poly, poly[1:] + poly[:1]):
        if (y0 > y) != (y1 > y) and x < x0 + (y - y0) * (x1 - x0) / (y1 - y0):
            inside = not inside
    return inside


def planar_faces(V, E):
    """半边结构提取平面面。返回 faces: [dict(loop, edges, holes=[[顶点...]], hole_edges, area(净), perim, cls_len)]。
    互不相连的线网（如外墙外线/内线未连、房间里的独立柱）：其外边界作为“洞”挂到包住它的最小面上。"""
    adj = defaultdict(list)
    ecls = {}
    for i, j, c in E:
        adj[i].append(j); adj[j].append(i)
        ecls[(i, j)] = ecls[(j, i)] = c
    order = {}
    for u, ns in adj.items():
        ux, uy = V[u]
        ns.sort(key=lambda w: math.atan2(V[w][1] - uy, V[w][0] - ux))
        order[u] = {w: k for k, w in enumerate(ns)}
    # 连通分量
    comp = {}
    for s in adj:
        if s in comp:
            continue
        stack = [s]; comp[s] = s
        while stack:
            a = stack.pop()
            for b in adj[a]:
                if b not in comp:
                    comp[b] = s; stack.append(b)
    used = set(); pos, neg = [], []
    for u in adj:
        for w in adj[u]:
            if (u, w) in used:
                continue
            loop, edges = [], []
            a, b = u, w
            while (a, b) not in used:
                used.add((a, b)); loop.append(a); edges.append((a, b))
                ns = adj[b]
                a, b = b, ns[(order[b][a] - 1) % len(ns)]
                if len(loop) > 200000:
                    break
            area = 0.0; perim = 0.0; cl = defaultdict(float)
            for (p, q) in edges:
                area += V[p][0] * V[q][1] - V[q][0] * V[p][1]
                L = math.dist(V[p], V[q]); perim += L; cl[ecls[(p, q)]] += L
            area /= 2
            rec = dict(loop=loop, edges=edges, area=area, perim=perim, cls_len=dict(cl), comp=comp[u], holes=[], hole_edges=[])
            (pos if area > 1e-9 else neg).append(rec)
    # 洞：每个分量的外边界（负向环）挂到别的分量里包住它的最小正向面
    for f in pos:
        xs = [V[i][0] for i in f["loop"]]; ys = [V[i][1] for i in f["loop"]]
        f["bbox"] = (min(xs), min(ys), max(xs), max(ys))
        f["poly"] = [V[i] for i in f["loop"]]
        f["gross"] = f["area"]
    by_area = sorted(pos, key=lambda f: f["gross"])
    for n in neg:
        pt = V[n["loop"][0]]
        for f in by_area:
            if f["comp"] == n["comp"] or f["gross"] < -n["area"]:
                continue
            b = f["bbox"]
            if b[0] <= pt[0] <= b[2] and b[1] <= pt[1] <= b[3] and _pip(pt, f["poly"]):
                f["holes"].append(n["loop"]); f["hole_edges"] += n["edges"]
                f["area"] += n["area"]; f["perim"] += n["perim"]
                for k, v in n["cls_len"].items():
                    f["cls_len"][k] = f["cls_len"].get(k, 0) + v
                break
    for f in pos:
        f.pop("poly", None)
    return pos


def classify(f, max_t=0.8, min_room=3.0, max_col=4.0):
    A, P = f['area'], f['perim']
    t = 2 * A / P if P else 0
    cl = f['cls_len']; tot = sum(cl.values()) or 1
    wf, of, cf = cl.get('wall', 0) / tot, cl.get('open', 0) / tot, cl.get('col', 0) / tot
    if cf > 0.5 and A <= max_col:
        return 'column'
    if t <= max_t:
        if wf >= 0.5:
            return 'wall'
        if wf + of >= 0.8 and of > 0:
            return 'window'
        return 'other'
    if A >= min_room:
        return 'room'
    return 'other'


# ---------------- 横切墙带 ----------------

def _ray_hit(o, d, V, edges, skip, max_len):
    best = None
    for (p, q) in edges:
        if p in skip or q in skip:
            continue
        a, b = V[p], V[q]
        sx, sy = b[0] - a[0], b[1] - a[1]
        den = d[0] * sy - d[1] * sx
        if abs(den) < 1e-12:
            continue
        t = ((a[0] - o[0]) * sy - (a[1] - o[1]) * sx) / den
        u = ((a[0] - o[0]) * d[1] - (a[1] - o[1]) * d[0]) / den
        if 1e-6 < t <= max_len and -1e-6 <= u <= 1 + 1e-6:
            if best is None or t < best:
                best = t
    return None if best is None else (o[0] + best * d[0], o[1] + best * d[1])


def junction_cuts(V, E, faces, kinds, max_t=0.8):
    """墙带上度数≥3 的顶点（有别的墙接进来），沿墙带法向横切到对边。"""
    deg = defaultdict(int)
    for i, j, _ in E:
        deg[i] += 1; deg[j] += 1
    cuts = []
    for f, k in zip(faces, kinds):
        if k != 'wall':
            continue
        edges = f['edges'] + f.get('hole_edges', [])
        for loop in [f['loop']] + f.get('holes', []):
          n = len(loop)
          for idx, v in enumerate(loop):
            if deg[v] < 3:
                continue
            prev, nxt = loop[idx - 1], loop[(idx + 1) % n]
            # 取较长的相邻边作为墙带方向
            e1 = (V[v][0] - V[prev][0], V[v][1] - V[prev][1]); e2 = (V[nxt][0] - V[v][0], V[nxt][1] - V[v][1])
            e = e1 if math.hypot(*e1) >= math.hypot(*e2) else e2
            L = math.hypot(*e)
            if L < 1e-9:
                continue
            dx, dy = -e[1] / L, e[0] / L  # 逆时针环，左侧为面内
            hit = _ray_hit(V[v], (dx, dy), V, edges, {v}, max_t * 1.5)
            if hit and math.dist(hit, V[v]) > 0.01:
                cuts.append((V[v], hit, 'wall'))
    return cuts


# ---------------- 总流程 ----------------

def build(segments, max_t=0.8, min_room=3.0, tol=0.003, split_at_junctions=True):
    V, E = node_segments(segments, tol)
    E = prune_dangling(V, E)
    faces = planar_faces(V, E)
    kinds = [classify(f, max_t, min_room) for f in faces]
    if split_at_junctions:
        cuts = junction_cuts(V, E, faces, kinds, max_t)
        if cuts:
            segs2 = [(V[i], V[j], c) for i, j, c in E] + cuts
            V, E = node_segments(segs2, tol)
            E = prune_dangling(V, E)
            faces = planar_faces(V, E)
            kinds = [classify(f, max_t, min_room) for f in faces]
    # 半边 → 面
    owner = {}
    for fi, f in enumerate(faces):
        for (a, b) in f['edges'] + f['hole_edges']:
            owner[(a, b)] = fi
    rooms = [fi for fi, k in enumerate(kinds) if k == 'room']
    assign = {}
    for fi, k in enumerate(kinds):
        if k not in ('wall', 'window'):
            continue
        contact = defaultdict(float)
        for (a, b) in faces[fi]['edges'] + faces[fi]['hole_edges']:
            o = owner.get((b, a))
            if o is not None and kinds[o] == 'room':
                contact[o] += math.dist(V[a], V[b])
        assign[fi] = max(contact, key=contact.get) if contact else None
    # 墙段只经过其他墙段接到空间的（如转角小块）：沿相邻墙段传递归属
    for _ in range(3):
        for fi, r in list(assign.items()):
            if r is not None:
                continue
            votes = defaultdict(float)
            for (a, b) in faces[fi]['edges'] + faces[fi]['hole_edges']:
                o = owner.get((b, a))
                if o in assign and assign[o] is not None:
                    votes[assign[o]] += math.dist(V[a], V[b])
            if votes:
                assign[fi] = max(votes, key=votes.get)
    return dict(V=V, faces=faces, kinds=kinds, rooms=rooms, assign=assign)


def polygon_centroid(V, loop):
    A = cx = cy = 0.0
    for a, b in zip(loop, loop[1:] + loop[:1]):
        (x0, y0), (x1, y1) = V[a], V[b]
        c = x0 * y1 - x1 * y0
        A += c; cx += (x0 + x1) * c; cy += (y0 + y1) * c
    A /= 2
    return (cx / (6 * A), cy / (6 * A)) if abs(A) > 1e-12 else V[loop[0]]
