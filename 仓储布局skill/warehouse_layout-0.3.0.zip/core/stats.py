"""实例统计、单元包围盒、高度对齐、验收报告。"""
import json
from collections import Counter, defaultdict

import bpy
from mathutils import Vector

from . import assets, nodes


def instance_stats(objs):
    """(网格实例数, 最小角, 最大角)。"""
    dg = bpy.context.evaluated_depsgraph_get()
    names = {o.name for o in objs}
    n = 0; lo = Vector((1e9,) * 3); hi = -lo
    for inst in dg.object_instances:
        if inst.is_instance and inst.parent and inst.parent.original.name in names and inst.object.type == 'MESH':
            n += 1
            for v in inst.object.bound_box:
                w = inst.matrix_world @ Vector(v)
                lo = Vector(map(min, lo, w)); hi = Vector(map(max, hi, w))
    return n, [round(x, 3) for x in lo], [round(x, 3) for x in hi]


def same_stats(a, b, tol=0.01):
    return a[0] == b[0] and all(abs(x - y) < tol for x, y in zip(a[1] + a[2], b[1] + b[2]))


def units(scope_objs=None):
    """求值后的“单元”（一个资产实例）列表：dict(asset, type, parent, lo, hi)。
    用每个资产的代表网格定位单元：单元变换 = 代表网格实例矩阵 @ 代表网格在资产内的矩阵⁻¹。"""
    rep = {}
    for c in assets.referenced_assets():
        info = assets.asset_info(c)
        if info['rep'] and info['rep_local'] is not None:
            rep[info['rep']] = (c.name, info, info['rep_local'].inverted())
    scope = {o.name for o in scope_objs} if scope_objs is not None else None
    dg = bpy.context.evaluated_depsgraph_get()
    out = []
    for inst in dg.object_instances:
        if not inst.is_instance or not inst.parent:
            continue
        r = rep.get(inst.object.original.name_full)
        if not r:
            continue
        par = inst.parent.original
        if scope is not None and par.name not in scope:
            continue
        name, info, inv = r
        U = inst.matrix_world @ inv
        lo, hi = info['lo'], info['hi']
        cs = [U @ Vector((x, y, z)) for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])]
        out.append(dict(asset=name, type=assets.classify(name), parent=par.name,
                        lo=[min(c[i] for c in cs) for i in range(3)], hi=[max(c[i] for c in cs) for i in range(3)]))
    return out


def rack_top(us=None):
    us = us if us is not None else units()
    tops = [u['hi'][2] for u in us if u['type'] == 'rack']
    return max(tops) if tops else None


def align_heights(objs, margin=1.0, include_stackers=True):
    """提升机顶 = 货架顶 + margin；堆垛机顶 = 货架顶。支持集合实例空对象与点位对象中的对应点。"""
    top = rack_top()
    if top is None:
        return dict(ok=False, msg="场景里没有识别到货架（按资产名分类规则）")
    changed = []
    for o in objs:
        k = nodes.kind(o)
        if k == 'empty':
            t = assets.classify(o.instance_collection.name)
            if t == 'hoist' or (include_stackers and t == 'stacker'):
                info = assets.asset_info(o.instance_collection)
                target = top + (margin if t == 'hoist' else 0.0)
                bottom = o.matrix_world.to_translation().z + info['lo'][2] * o.scale.z
                o.scale.z = (target - bottom) / info['size'][2]
                changed.append(f"{o.name}→{target:.2f}m")
        elif k == 'point':
            me = o.data; n = len(me.vertices)
            ga = assets.group_assets()
            idx = [0] * n; me.attributes["idx"].data.foreach_get("value", idx)
            size = [0.0] * (3 * n); me.attributes["size"].data.foreach_get("vector", size)
            lift = nodes.get_params(o, nodes.POINT_MOD)["离地高度"]
            hit = 0
            for i, v in enumerate(me.vertices):
                t = assets.classify(ga[idx[i]].name)
                if t == 'hoist' or (include_stackers and t == 'stacker'):
                    target = top + (margin if t == 'hoist' else 0.0)
                    size[3 * i + 2] = target - ((o.matrix_world @ v.co).z + lift)
                    hit += 1
            if hit:
                me.attributes["size"].data.foreach_set("vector", size); me.update(); o.update_tag()
                changed.append(f"{o.name}({hit}点)")
    bpy.context.view_layer.update()
    return dict(ok=True, rack_top=top, changed=changed, msg=f"货架顶 {top:.2f}m，调整 {len(changed)} 个对象")


def _xy_overlap(a, b, eps=0.02):
    return (min(a['hi'][0], b['hi'][0]) - max(a['lo'][0], b['lo'][0]) > eps and
            min(a['hi'][1], b['hi'][1]) - max(a['lo'][1], b['lo'][1]) > eps and
            min(a['hi'][2], b['hi'][2]) - max(a['lo'][2], b['lo'][2]) > eps)


def _xy_contains(box, x, y, tol=0.02):
    return box['lo'][0] - tol <= x <= box['hi'][0] + tol and box['lo'][1] - tol <= y <= box['hi'][1] + tol


def _rail_checks(us):
    """每条轨道（巷道）恰好一台堆垛机；每条轨道至少一端被护栏在平面上完全覆盖。"""
    rails = [u for u in us if u['type'] == 'rail']
    if not rails:
        return []
    st = [u for u in us if u['type'] == 'stacker']
    guards = [u for u in us if u['type'] == 'guard']
    out = []

    def on_rail(s, r):
        cx = (s['lo'][0] + s['hi'][0]) / 2; cy = (s['lo'][1] + s['hi'][1]) / 2
        return _xy_contains(r, cx, cy, tol=0.5)
    counts = [sum(1 for s in st if on_rail(s, r)) for r in rails]
    bad = [c for c in counts if c != 1]
    out.append(("每巷道一台堆垛机", "PASS" if not bad else "FAIL",
                f"{len(rails)}条轨道，堆垛机 {len(st)} 台" + ("" if not bad else f"；{len(bad)}条轨道数量≠1（{sorted(set(bad))}）")))
    if guards:
        uncovered = 0
        for r in rails:
            long_x = (r['hi'][0] - r['lo'][0]) >= (r['hi'][1] - r['lo'][1])
            ends = ([(r['lo'][0], r['lo'][1]), (r['lo'][0], r['hi'][1])], [(r['hi'][0], r['lo'][1]), (r['hi'][0], r['hi'][1])]) if long_x \
                else ([(r['lo'][0], r['lo'][1]), (r['hi'][0], r['lo'][1])], [(r['lo'][0], r['hi'][1]), (r['hi'][0], r['hi'][1])])
            if not any(all(any(_xy_contains(g, x, y) for g in guards) for x, y in end) for end in ends):
                uncovered += 1
        out.append(("护栏覆盖轨道端部", "PASS" if not uncovered else "FAIL",
                    f"{len(rails) - uncovered}/{len(rails)} 条轨道端部被护栏覆盖"))
    return out


def validate(scope_objs=None, margin_range=(0.3, 2.0), stacker_tol=0.3):
    us = units(scope_objs)
    by_asset = Counter(u['asset'] for u in us)
    by_type = Counter(assets.TYPE_LABEL.get(u['type'], u['type']) for u in us)
    top = rack_top(us)
    checks = []
    if top is None:
        checks.append(("货架", "WARN", "未识别到货架"))
    else:
        hoists = [u for u in us if u['type'] == 'hoist']
        bad = [u for u in hoists if not (margin_range[0] <= u['hi'][2] - top <= margin_range[1])]
        if hoists:
            checks.append(("提升机高于货架", "PASS" if not bad else "FAIL",
                           f"{len(hoists)}台，货架顶{top:.2f}m，提升机顶 " +
                           ",".join(sorted({"%.2f" % u['hi'][2] for u in hoists})) +
                           ("" if not bad else f"；{len(bad)}台不在 +{margin_range[0]}~{margin_range[1]}m 范围")))
        st = [u for u in us if u['type'] == 'stacker']
        if st:
            bad = [u for u in st if abs(u['hi'][2] - top) > stacker_tol]
            checks.append(("堆垛机≈货架顶", "PASS" if not bad else "FAIL",
                           f"{len(st)}台" + ("" if not bad else f"，{len(bad)}台偏差>{stacker_tol}m")))
            racks = [u for u in us if u['type'] == 'rack']
            hit = sum(1 for s in st if any(_xy_overlap(s, r) for r in racks))
            checks.append(("堆垛机与货架干涉", "PASS" if not hit else "FAIL", f"{hit}台干涉"))
    checks += _rail_checks(us)
    objs = scope_objs if scope_objs is not None else list(bpy.context.scene.objects)
    kinds = Counter(nodes.kind(o) or "其他" for o in objs)
    lines = [f"单元总数 {len(us)}；对象：XYZ阵列 {kinds.get('xyz', 0)}，点位 {kinds.get('point', 0)}，空对象实例 {kinds.get('empty', 0)}",
             "按类型：" + "，".join(f"{k} {v}" for k, v in by_type.most_common()),
             "按资产：" + "，".join(f"{k} {v}" for k, v in by_asset.most_common())]
    lines += [f"[{s}] {n}：{d}" for n, s, d in checks]
    fails = sum(1 for _, s, _ in checks if s == "FAIL")
    summary = f"验收：{'通过' if not fails else f'{fails} 项未通过'}（{len(checks)} 项检查）"
    text = summary + "\n" + "\n".join(lines)
    t = bpy.data.texts.get("WH_验收报告") or bpy.data.texts.new("WH_验收报告")
    t.clear(); t.write(text)
    bpy.context.scene["wh_last_report"] = text
    return dict(ok=not fails, summary=summary, text=text,
                data=dict(units=len(us), by_asset=dict(by_asset), by_type=dict(by_type), rack_top=top,
                          checks=[dict(name=n, status=s, detail=d) for n, s, d in checks]))


def dump_json(result, path):
    with open(bpy.path.abspath(path), "w", encoding="utf-8") as f:
        json.dump(result["data"], f, ensure_ascii=False, indent=2)
