"""一键挤出墙体：复用底图解析结果（缓存）→ 墙/门窗/柱线段 → walls.build → 每个空间一个墙体对象（GN 挤出，高度可调）+ 柱子。"""
import re
from collections import defaultdict

import bpy

from . import underlay, walls

WALL_GN = "GN_墙体挤出"
WALL_MOD = "墙体挤出"
DEFAULT_PATTERNS = {"wall": r"WALL|墙", "open": r"WIN|DOOR|门|窗", "col": r"COLU|柱(?!片)"}


def wall_config(path):
    import json
    with open(bpy.path.abspath(path), encoding="utf-8") as f:
        c = json.load(f)
    w = c.get("walls") or {}
    return dict(
        height=w.get("height"), column_height=w.get("column_height"), base_z=float(w.get("base_z", 0.0)),
        wall_layers=w.get("wall_layers") or [], opening_layers=w.get("opening_layers") or [], column_layers=w.get("column_layers") or [],
        max_thickness=float(w.get("max_thickness", 0.8)), min_room_area=float(w.get("min_room_area", 3.0)),
        include_windows=bool(w.get("include_windows", True)), floors=bool(w.get("floors", False)),
    )


def classify_layers(layers, wc):
    explicit = {"wall": set(wc["wall_layers"]), "open": set(wc["opening_layers"]), "col": set(wc["column_layers"])}
    out = {}
    for lay in layers:
        if any(explicit.values()):
            for k, s in explicit.items():
                if lay in s:
                    out[lay] = k
        else:
            for k in ("col", "open", "wall"):  # 顺序：柱 > 门窗 > 墙（“WALL”可能出现在窗图层名里）
                if re.search(DEFAULT_PATTERNS[k], lay, re.I):
                    out[lay] = k
                    break
    return out


def ensure_wall_group(rebuild=False):
    ng = bpy.data.node_groups.get(WALL_GN)
    if ng and not rebuild:
        return ng
    if ng:
        bpy.data.node_groups.remove(ng)
    ng = bpy.data.node_groups.new(WALL_GN, 'GeometryNodeTree')
    I = ng.interface
    I.new_socket("Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    s = I.new_socket("高度", in_out='INPUT', socket_type='NodeSocketFloat'); s.default_value = 6.0; s.min_value = 0.0
    s = I.new_socket("底标高", in_out='INPUT', socket_type='NodeSocketFloat'); s.default_value = 0.0
    I.new_socket("Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    N, L = ng.nodes, ng.links
    gi = N.new('NodeGroupInput'); go = N.new('NodeGroupOutput')
    ex = N.new('GeometryNodeExtrudeMesh'); ex.mode = 'FACES'
    L.new(gi.outputs["Geometry"], ex.inputs['Mesh'])
    ex.inputs['Offset'].default_value = (0, 0, 1)
    L.new(gi.outputs["高度"], ex.inputs['Offset Scale'])
    ex.inputs['Individual'].default_value = False
    flip = N.new('GeometryNodeFlipFaces'); L.new(gi.outputs["Geometry"], flip.inputs['Mesh'])
    join = N.new('GeometryNodeJoinGeometry')
    L.new(ex.outputs['Mesh'], join.inputs[0]); L.new(flip.outputs[0], join.inputs[0])
    merge = N.new('GeometryNodeMergeByDistance'); L.new(join.outputs[0], merge.inputs['Geometry'])
    off = N.new('ShaderNodeCombineXYZ'); L.new(gi.outputs["底标高"], off.inputs[2])
    sp = N.new('GeometryNodeSetPosition'); L.new(merge.outputs[0], sp.inputs['Geometry']); L.new(off.outputs[0], sp.inputs['Offset'])
    L.new(sp.outputs[0], go.inputs[0])
    for i, n in enumerate(N):
        n.location = (i * 200, 0)
    return ng


def _mesh_from_faces(name, V, fs):
    """fs: walls.planar_faces 的面（可带洞）。无洞 → n 边形；有洞 → 三角剖分。"""
    from mathutils import Vector
    from mathutils.geometry import tessellate_polygon
    idx = {}
    verts, faces = [], []

    def vi(v):
        if v not in idx:
            idx[v] = len(verts); verts.append((V[v][0], V[v][1], 0.0))
        return idx[v]
    for f in fs:
        if not f.get("holes"):
            faces.append([vi(v) for v in f["loop"]])
            continue
        rings = [f["loop"]] + f["holes"]
        flat = [v for r in rings for v in r]
        tris = tessellate_polygon([[Vector((V[v][0], V[v][1], 0.0)) for v in r] for r in rings])
        for a, b, c in tris:
            tri = [vi(flat[a]), vi(flat[b]), vi(flat[c])]
            # 与外环同向（逆时针，法线 +Z）
            (x0, y0, _), (x1, y1, _), (x2, y2, _) = (verts[i] for i in tri)
            if (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0) < 0:
                tri.reverse()
            faces.append(tri)
    me = bpy.data.meshes.new(name)
    me.from_pydata(verts, [], faces)
    me.validate(clean_customdata=False)
    me.update()
    return me


def _add_wall_object(name, me, coll, height, base_z, props):
    ob = bpy.data.objects.new(name, me)
    for k, v in props.items():
        ob[k] = v
    coll.objects.link(ob)
    m = ob.modifiers.new(WALL_MOD, 'NODES'); m.node_group = ensure_wall_group()
    ids = {s.name: s.identifier for s in m.node_group.interface.items_tree if s.in_out == 'INPUT'}
    m[ids["高度"]] = float(height); m[ids["底标高"]] = float(base_z)
    return ob


def _child(parent, name):
    c = bpy.data.collections.get(name)
    if c is None:
        c = bpy.data.collections.new(name)
    if c.name not in parent.children:
        parent.children.link(c)
    return c


def build_walls(ucfg, wc, height=None, column_height=None, replace=True):
    data, cached = underlay.extract(ucfg)
    cls = classify_layers(list(data), wc)
    if not any(v == "wall" for v in cls.values()):
        return dict(ok=False, msg="底图里没有识别到墙图层（检查 walls.wall_layers 或底图区域/排除图层）")
    segs = []
    for lay, k in cls.items():
        verts, edges, _ = data[lay]
        for i, j in edges:
            segs.append(((float(verts[i][0]), float(verts[i][1])), (float(verts[j][0]), float(verts[j][1])), k))
    R = walls.build(segs, max_t=wc["max_thickness"], min_room=wc["min_room_area"])
    V, faces, kinds, assign = R["V"], R["faces"], R["kinds"], R["assign"]
    rooms = sorted(R["rooms"], key=lambda i: -faces[i]["area"])
    rid = {r: n + 1 for n, r in enumerate(rooms)}
    H = height if height and height > 0 else (wc["height"] or 6.0)
    CH = column_height if column_height and column_height > 0 else (wc["column_height"] or H)

    root = bpy.data.collections.get(f"建筑_{ucfg['name']}")
    if root is None:
        root = bpy.data.collections.new(f"建筑_{ucfg['name']}")
        bpy.context.scene.collection.children.link(root)
    cw, cc = _child(root, f"墙体_{ucfg['name']}"), _child(root, f"柱子_{ucfg['name']}")
    cf = _child(root, f"空间地面_{ucfg['name']}") if wc["floors"] else None
    if replace:
        for c in (cw, cc, cf):
            if c:
                for o in list(c.objects):
                    me = o.data; bpy.data.objects.remove(o)
                    if me and me.users == 0:
                        bpy.data.meshes.remove(me)

    groups = defaultdict(list)
    for fi, r in assign.items():
        if kinds[fi] == "window" and (r is None or not wc["include_windows"]):
            continue  # 不接触任何空间的窗块（多为外墙外侧的窗框符号）不挤出
        groups[r].append(fi)
    made = 0
    for r, fis in sorted(groups.items(), key=lambda kv: (kv[0] is None, rid.get(kv[0], 0))):
        name = f"墙体_空间{rid[r]:02d}" if r is not None else "墙体_未归属"
        me = _mesh_from_faces(name, V, [faces[fi] for fi in fis])
        props = {"wh_建筑": "墙体", "墙段数": len(fis)}
        if r is not None:
            props["空间"] = f"空间{rid[r]:02d}"; props["空间面积㎡"] = round(faces[r]["area"], 1)
        _add_wall_object(name, me, cw, H, wc["base_z"], props)
        made += 1
    cols = [fi for fi, k in enumerate(kinds) if k == "column"]
    if cols:
        _add_wall_object(f"柱子_{ucfg['name']}", _mesh_from_faces("柱子", V, [faces[fi] for fi in cols]), cc, CH, wc["base_z"],
                         {"wh_建筑": "柱子", "柱数": len(cols)})
    if cf:
        for r in rooms:
            ob = bpy.data.objects.new(f"空间{rid[r]:02d}", _mesh_from_faces(f"空间{rid[r]:02d}", V, [faces[r]]))
            ob.location.z = wc["base_z"] - 0.02; ob["空间面积㎡"] = round(faces[r]["area"], 1); ob.display_type = 'WIRE'
            cf.objects.link(ob)
    n_wall = sum(1 for k in kinds if k == "wall")
    un = len(groups.get(None, []))
    return dict(ok=True, rooms=len(rooms), wall_objects=made, wall_pieces=n_wall, columns=len(cols), unassigned=un,
                height=H, column_height=CH, cached=cached,
                msg=f"{len(rooms)} 个空间 → {made} 个墙体对象（墙段 {n_wall}，未归属 {un}），柱 {len(cols)}，墙高 {H:g}m")
