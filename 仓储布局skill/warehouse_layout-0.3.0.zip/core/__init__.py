# 核心层：不含 UI，可被操作器与脚本直接调用
ROOT_PACKAGE = None  # 由插件 register() 写入，用于读取偏好设置


def prefs():
    import bpy
    if ROOT_PACKAGE and ROOT_PACKAGE in bpy.context.preferences.addons:
        return bpy.context.preferences.addons[ROOT_PACKAGE].preferences
    return None
