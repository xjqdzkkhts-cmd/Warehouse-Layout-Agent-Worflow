"""单元提取（空对象 / 点位对象）→ 构建 XYZ 阵列或点位对象；带替换校验与回滚。"""
import math

import bpy
from mathutils import Matrix

from . import assets, nodes, decompose, stats


# ---------------- 单元提取 ----------------

def _center(loc_xy, rz, base_xy, scale_xy):
    c, s = math.cos(rz), math.sin(rz)
    bx, by = base_xy[0] * scale_xy[0], base_xy[1] * scale_xy[1]
    return loc_xy[0] + c * bx - s * by, loc_xy[1] + s * bx + c * by


def units_from_empty(o):
    coll = o.instance_collection
    info = assets.asset_info(coll)
    s = info['size']
    mw = o.matrix_world
    loc = mw.to_translation(); rz = mw.to_euler().z; sc = mw.to_scale()
    cx, cy = _center(loc, rz, info['base'], sc)
    return [dict(asset=coll.name, cx=cx, cy=cy, bottom=loc.z + info['lo'][2] * sc.z, rz=rz,
                 ux=s[0] * sc.x, uy=s[1] * sc.y, uz=s[2] * sc.z, src=o.name)]


def units_from_point(o):
    """点位对象：读属性 + 修改器参数（竖向节数/总高/排深覆盖/离地高度），展开为单元。"""
    me = o.data; n = len(me.vertices)
    p = nodes.get_params(o, nodes.POINT_MOD)
    ga = assets.group_assets()

    def vec(name):
        a = [0.0] * (3 * n); me.attributes[name].data.foreach_get("vector", a)
        return [a[3 * i:3 * i + 3] for i in range(n)]
    size, asize, rot = vec("size"), vec("asize"), vec("rot")
    idx = [0] * n; me.attributes["idx"].data.foreach_get("value", idx)
    mw = o.matrix_world
    oz = mw.to_euler().z
    out = []
    for i, v in enumerate(me.vertices):
        coll = ga[idx[i]]
        info = assets.asset_info(coll)
        H = p["总高"] if p["总高"] > 0 else size[i][2]
        depth = p["排深覆盖"] if p["排深覆盖"] > 0 else size[i][1]
        nsec = max(1, p["竖向节数"]); sec_h = H / nsec
        sc = (size[i][0] / asize[i][0], depth / asize[i][1], sec_h / asize[i][2])
        w = mw @ v.co
        rz = rot[i][2] + oz
        cx, cy = _center(w, rz, info['base'], sc)
        for k in range(nsec):
            out.append(dict(asset=coll.name, cx=cx, cy=cy, bottom=w.z + p["离地高度"] + k * sec_h + info['lo'][2] * sc[2],
                            rz=rz, ux=size[i][0], uy=depth, uz=sec_h, src=o.name))
    return out


def units_from(objs):
    out, skipped = [], []
    for o in objs:
        k = nodes.kind(o)
        if k == 'empty':
            out += units_from_empty(o)
        elif k == 'point':
            out += units_from_point(o)
        else:
            skipped.append(o.name)
    return out, skipped


# ---------------- 构建 ----------------

def _parent(name, loc, coll):
    p = bpy.data.objects.new(name, None)
    p.empty_display_type = 'PLAIN_AXES'; p.empty_display_size = 1.0
    p.location = (loc[0], loc[1], 0.0)
    coll.objects.link(p)
    return p


def _attach(ob, p):
    # 新对象 matrix_world 在视图层更新前为单位矩阵，必须用父级自身变换求逆，否则位移叠加两次
    ob.parent = p
    ob.matrix_parent_inverse = Matrix.LocRotScale(p.location, p.rotation_euler, p.scale).inverted()


def build_xyz(name, a, coll):
    ng = nodes.ensure_xyz_group()
    ac = assets.asset_collection(a['asset'])
    info = assets.asset_info(ac)
    ob = bpy.data.objects.new(name, bpy.data.meshes.new(name))
    ob.location = (a['origin'][0], a['origin'][1], 0.0); ob.rotation_euler = (0, 0, a['rz'])
    ob["wh_类型"] = assets.TYPE_LABEL.get(assets.classify(a['asset']), "其他")
    coll.objects.link(ob)
    m = ob.modifiers.new(nodes.XYZ_MOD, 'NODES'); m.node_group = ng
    ids = nodes.socket_ids(ng)
    vals = {"资产": ac, "资产尺寸": tuple(info['size']), "资产基点": tuple(info['base']),
            "X数量": int(a['nx']), "X间距": float(a['dx']), "Y数量": int(a['ny']), "Y间距": float(a['dy']),
            "Z数量": int(a['nz']), "Z间距": float(a['dz']),
            "单元长X": float(a['ux']), "单元深Y": float(a['uy']), "单元高Z": float(a['uz']), "离地高度": float(a['lift'])}
    for k, v in vals.items():
        m[ids[k]] = v
    return ob


def build_point(name, pts, coll, sections=1, total_height=0.0, lift=0.0):
    """pts: dict(x,y,z 实例原点, asset, sx,sy,sz 目标尺寸, rz)"""
    ng = nodes.ensure_point_group()
    idx = assets.ensure_asset_group(sorted({p["asset"] for p in pts}))
    sizes = {a: assets.asset_info(assets.asset_collection(a))['size'] for a in idx}
    me = bpy.data.meshes.new(name)
    me.from_pydata([(p["x"], p["y"], p.get("z", 0.0)) for p in pts], [], [])
    for an, dt in (("size", 'FLOAT_VECTOR'), ("asize", 'FLOAT_VECTOR'), ("rot", 'FLOAT_VECTOR'), ("idx", 'INT')):
        me.attributes.new(an, dt, 'POINT')
    me.attributes["size"].data.foreach_set("vector", [c for p in pts for c in (p["sx"], p["sy"], p["sz"])])
    me.attributes["asize"].data.foreach_set("vector", [c for p in pts for c in sizes[p["asset"]]])
    me.attributes["rot"].data.foreach_set("vector", [c for p in pts for c in (0.0, 0.0, p.get("rz", 0.0))])
    me.attributes["idx"].data.foreach_set("value", [idx[p["asset"]] for p in pts])
    ob = bpy.data.objects.new(name, me)
    types = {assets.TYPE_LABEL.get(assets.classify(p["asset"]), "其他") for p in pts}
    ob["wh_类型"] = "/".join(sorted(types))
    coll.objects.link(ob)
    m = ob.modifiers.new(nodes.POINT_MOD, 'NODES'); m.node_group = ng
    ids = nodes.socket_ids(ng)
    m[ids["资产组"]] = bpy.data.collections[assets.GROUP_NAME]
    m[ids["竖向节数"]] = int(sections); m[ids["总高"]] = float(total_height)
    m[ids["排深覆盖"]] = 0.0; m[ids["离地高度"]] = float(lift)
    return ob


def point_from_empty(o):
    info = assets.asset_info(o.instance_collection)
    s = info['size']; mw = o.matrix_world
    loc = mw.to_translation(); sc = mw.to_scale()
    return dict(x=loc.x, y=loc.y, z=loc.z, asset=o.instance_collection.name,
                sx=sc.x * s[0], sy=sc.y * s[1], sz=sc.z * s[2], rz=mw.to_euler().z)


# ---------------- 替换（校验 + 回滚） ----------------

def _replace(sources, make, keep_source=False):
    """make() -> 新对象列表。实例数与包围盒一致才删除/隐藏源对象，否则删除新对象并回滚。"""
    before = stats.instance_stats(sources)
    new = make()
    bpy.context.view_layer.update()
    after = stats.instance_stats([o for o in new if o.type == 'MESH'])
    ok = stats.same_stats(before, after)
    if ok:
        for o in sources:
            if keep_source:
                o.hide_set(True); o.hide_render = True
            else:
                bpy.data.objects.remove(o)
    else:
        for o in new:
            bpy.data.objects.remove(o)
    return ok, before, after, new if ok else []


def to_xyz(sources, coll, prefix, merge_y=True, group_mode="CLUSTER", gap=0.5, max_dx=3.2, max_dy=1.6, keep_source=False):
    units, skipped = units_from(sources)
    srcs = [o for o in sources if o.name not in skipped]
    if not units:
        return dict(ok=False, msg="没有可转换的单元（只支持集合实例空对象和点位对象）", skipped=skipped)
    arrays = decompose.plan_arrays(units, merge_y=merge_y, max_dx=max_dx, max_dy=max_dy)
    n_units = sum(a['nx'] * a['ny'] * a['nz'] for a in arrays)
    if n_units != len(units):
        return dict(ok=False, msg=f"分解后单元数 {n_units} ≠ 源单元数 {len(units)}，已中止", skipped=skipped)
    assets.ensure_asset_group(sorted({a['asset'] for a in arrays}))
    groups = decompose.group_arrays(arrays, group_mode, gap)

    def make():
        new = []
        for gi, idxs in enumerate(groups):
            if len(idxs) == 1 or group_mode == "NONE":
                for k, i in enumerate(idxs):
                    new.append(build_xyz(f"{prefix}_{gi + 1:02d}" if len(idxs) == 1 else f"{prefix}_{gi + 1:02d}_段{k + 1}", arrays[i], coll))
            else:
                p = _parent(f"{prefix}_{gi + 1:02d}", arrays[idxs[0]]['origin'], coll)
                new.append(p)
                for k, i in enumerate(sorted(idxs, key=lambda i: (arrays[i]['lx'], arrays[i]['ly']))):
                    ob = build_xyz(f"{prefix}_{gi + 1:02d}_段{k + 1}", arrays[i], coll)
                    _attach(ob, p); new.append(ob)
        return new

    ok, before, after, new = _replace(srcs, make, keep_source)
    return dict(ok=ok, units=len(units), arrays=len(arrays), groups=len(groups), before=before, after=after,
                skipped=skipped, msg=("完成" if ok else "校验不一致，已回滚"))


def to_points(sources, coll, prefix, group_mode="LINE", keep_source=False):
    empties = [o for o in sources if nodes.kind(o) == 'empty']
    skipped = [o.name for o in sources if nodes.kind(o) != 'empty']
    if not empties:
        return dict(ok=False, msg="没有集合实例空对象", skipped=skipped)
    pts = [point_from_empty(o) for o in empties]
    if group_mode == "LINE":
        boxes = []
        for o in empties:
            u = units_from_empty(o)[0]
            c, s = abs(math.cos(u['rz'])), abs(math.sin(u['rz']))
            boxes.append((u['cx'], u['cy'], c * u['ux'] + s * u['uy'], s * u['ux'] + c * u['uy']))
        # 同一位置多件（如机架+顶升）按同一位置合并判断
        groups = decompose.group_lines(boxes)
    else:
        groups = [('A', list(range(len(empties))))]

    def make():
        new = []
        hs = sorted([g for g in groups if g[0] != 'V'], key=lambda g: sum(boxes[i][1] for i in g[1]) / len(g[1])) if group_mode == "LINE" else groups
        vs = sorted([g for g in groups if g[0] == 'V'], key=lambda g: sum(boxes[i][0] for i in g[1]) / len(g[1])) if group_mode == "LINE" else []
        for tag, gs in (("横", hs), ("纵", vs)):
            for i, (_, idxs) in enumerate(gs):
                nm = f"{prefix}_{tag}{i + 1:02d}" if group_mode == "LINE" else prefix
                new.append(build_point(nm, [pts[j] for j in idxs], coll))
        return new

    ok, before, after, new = _replace(empties, make, keep_source)
    return dict(ok=ok, units=len(empties), objects=len(new), before=before, after=after, skipped=skipped,
                msg=("完成" if ok else "校验不一致，已回滚"))
