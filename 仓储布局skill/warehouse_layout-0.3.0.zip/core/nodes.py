"""两个几何节点组：GN_点位实例（不规则、多资产混排）与 GN_XYZ阵列（规则阵列，三轴分别设数量/间距）。"""
import bpy

POINT_GN = "GN_点位实例"
XYZ_GN = "GN_XYZ阵列"
POINT_MOD = "点位参数"
XYZ_MOD = "XYZ阵列"


class _B:
    def __init__(self, ng):
        self.N, self.L = ng.nodes, ng.links

    def math(self, op, a, b):
        m = self.N.new('ShaderNodeMath'); m.operation = op
        for i, v in enumerate((a, b)):
            if isinstance(v, (int, float)):
                m.inputs[i].default_value = v
            else:
                self.L.new(v, m.inputs[i])
        return m.outputs[0]

    def override(self, param, fallback):
        """param > 0 ? param : fallback"""
        c = self.N.new('FunctionNodeCompare'); c.data_type = 'FLOAT'; c.operation = 'GREATER_THAN'
        self.L.new(param, c.inputs[0]); c.inputs[1].default_value = 0.0
        sw = self.N.new('GeometryNodeSwitch'); sw.input_type = 'FLOAT'
        self.L.new(c.outputs[0], sw.inputs['Switch']); self.L.new(fallback, sw.inputs['False']); self.L.new(param, sw.inputs['True'])
        return sw.outputs[0]

    def attr(self, name, dtype='FLOAT_VECTOR'):
        n = self.N.new('GeometryNodeInputNamedAttribute'); n.data_type = dtype; n.inputs['Name'].default_value = name
        return n.outputs['Attribute']

    def layout(self):
        for i, n in enumerate(self.N):
            n.location = ((i % 8) * 200, -(i // 8) * 250)


def _new_group(name, inputs):
    ng = bpy.data.node_groups.new(name, 'GeometryNodeTree')
    I = ng.interface
    I.new_socket("Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    for nm, st, dv, mn in inputs:
        s = I.new_socket(nm, in_out='INPUT', socket_type=st)
        if dv is not None:
            s.default_value = dv
        if mn is not None:
            s.min_value = mn
    I.new_socket("Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    return ng


def ensure_point_group(rebuild=False):
    ng = bpy.data.node_groups.get(POINT_GN)
    if ng and not rebuild:
        return ng
    if ng:
        bpy.data.node_groups.remove(ng)
    ng = _new_group(POINT_GN, [
        ("资产组", 'NodeSocketCollection', None, None),
        ("竖向节数", 'NodeSocketInt', 1, 1),
        ("总高", 'NodeSocketFloat', 0.0, 0.0),
        ("排深覆盖", 'NodeSocketFloat', 0.0, 0.0),
        ("离地高度", 'NodeSocketFloat', 0.0, None),
    ])
    b = _B(ng); N, L = b.N, b.L
    gi = N.new('NodeGroupInput'); go = N.new('NodeGroupOutput'); g = gi.outputs
    size = N.new('ShaderNodeSeparateXYZ'); L.new(b.attr("size"), size.inputs[0])
    asize = N.new('ShaderNodeSeparateXYZ'); L.new(b.attr("asize"), asize.inputs[0])
    height = b.override(g["总高"], size.outputs[2])
    depth = b.override(g["排深覆盖"], size.outputs[1])
    sec_h = b.math('DIVIDE', height, g["竖向节数"])
    lift = N.new('ShaderNodeCombineXYZ'); L.new(g["离地高度"], lift.inputs[2])
    setp = N.new('GeometryNodeSetPosition'); L.new(g["Geometry"], setp.inputs['Geometry']); L.new(lift.outputs[0], setp.inputs['Offset'])
    line = N.new('GeometryNodeMeshLine'); line.mode = 'OFFSET'
    L.new(g["竖向节数"], line.inputs['Count']); line.inputs['Offset'].default_value = (0, 0, 1)
    s1 = N.new('ShaderNodeCombineXYZ'); s1.inputs[0].default_value = 1; s1.inputs[1].default_value = 1; L.new(sec_h, s1.inputs[2])
    i1 = N.new('GeometryNodeInstanceOnPoints'); L.new(setp.outputs[0], i1.inputs['Points']); L.new(line.outputs[0], i1.inputs['Instance']); L.new(s1.outputs[0], i1.inputs['Scale'])
    r1 = N.new('GeometryNodeRealizeInstances'); L.new(i1.outputs[0], r1.inputs[0])
    sc = N.new('ShaderNodeCombineXYZ')
    L.new(b.math('DIVIDE', size.outputs[0], asize.outputs[0]), sc.inputs[0])
    L.new(b.math('DIVIDE', depth, asize.outputs[1]), sc.inputs[1])
    L.new(b.math('DIVIDE', sec_h, asize.outputs[2]), sc.inputs[2])
    ci = N.new('GeometryNodeCollectionInfo'); ci.transform_space = 'ORIGINAL'
    L.new(g["资产组"], ci.inputs['Collection'])
    ci.inputs['Separate Children'].default_value = True; ci.inputs['Reset Children'].default_value = True
    i2 = N.new('GeometryNodeInstanceOnPoints')
    L.new(r1.outputs[0], i2.inputs['Points']); L.new(ci.outputs[0], i2.inputs['Instance'])
    i2.inputs['Pick Instance'].default_value = True
    L.new(b.attr("idx", 'INT'), i2.inputs['Instance Index'])
    L.new(b.attr("rot"), i2.inputs['Rotation']); L.new(sc.outputs[0], i2.inputs['Scale'])
    L.new(i2.outputs[0], go.inputs[0])
    b.layout()
    return ng


def ensure_xyz_group(rebuild=False):
    ng = bpy.data.node_groups.get(XYZ_GN)
    if ng and not rebuild:
        return ng
    if ng:
        bpy.data.node_groups.remove(ng)
    ng = _new_group(XYZ_GN, [
        ("资产", 'NodeSocketCollection', None, None),
        ("资产尺寸", 'NodeSocketVector', (1.0, 1.0, 1.0), None),
        ("资产基点", 'NodeSocketVector', (0.0, 0.0, 0.0), None),
        ("X数量", 'NodeSocketInt', 1, 1), ("X间距", 'NodeSocketFloat', 1.0, None),
        ("Y数量", 'NodeSocketInt', 1, 1), ("Y间距", 'NodeSocketFloat', 1.0, None),
        ("Z数量", 'NodeSocketInt', 1, 1), ("Z间距", 'NodeSocketFloat', 1.0, None),
        ("单元长X", 'NodeSocketFloat', 0.0, 0.0), ("单元深Y", 'NodeSocketFloat', 0.0, 0.0), ("单元高Z", 'NodeSocketFloat', 0.0, 0.0),
        ("离地高度", 'NodeSocketFloat', 0.0, None),
    ])
    b = _B(ng); N, L = b.N, b.L
    gi = N.new('NodeGroupInput'); go = N.new('NodeGroupOutput'); g = gi.outputs

    def line(count, spacing, axis):
        c = N.new('ShaderNodeCombineXYZ'); L.new(spacing, c.inputs[axis])
        ml = N.new('GeometryNodeMeshLine'); ml.mode = 'OFFSET'
        L.new(count, ml.inputs['Count']); L.new(c.outputs[0], ml.inputs['Offset'])
        return ml.outputs[0]

    lx, ly, lz = line(g["X数量"], g["X间距"], 0), line(g["Y数量"], g["Y间距"], 1), line(g["Z数量"], g["Z间距"], 2)
    i1 = N.new('GeometryNodeInstanceOnPoints'); L.new(lx, i1.inputs['Points']); L.new(ly, i1.inputs['Instance'])
    r1 = N.new('GeometryNodeRealizeInstances'); L.new(i1.outputs[0], r1.inputs[0])
    i2 = N.new('GeometryNodeInstanceOnPoints'); L.new(r1.outputs[0], i2.inputs['Points']); L.new(lz, i2.inputs['Instance'])
    r2 = N.new('GeometryNodeRealizeInstances'); L.new(i2.outputs[0], r2.inputs[0])
    lift = N.new('ShaderNodeCombineXYZ'); L.new(g["离地高度"], lift.inputs[2])
    sp = N.new('GeometryNodeSetPosition'); L.new(r2.outputs[0], sp.inputs['Geometry']); L.new(lift.outputs[0], sp.inputs['Offset'])
    asz = N.new('ShaderNodeSeparateXYZ'); L.new(g["资产尺寸"], asz.inputs[0])
    sc = N.new('ShaderNodeCombineXYZ')
    L.new(b.math('DIVIDE', b.override(g["单元长X"], g["X间距"]), asz.outputs[0]), sc.inputs[0])
    L.new(b.math('DIVIDE', b.override(g["单元深Y"], g["Y间距"]), asz.outputs[1]), sc.inputs[1])
    L.new(b.math('DIVIDE', b.override(g["单元高Z"], g["Z间距"]), asz.outputs[2]), sc.inputs[2])
    ci = N.new('GeometryNodeCollectionInfo'); ci.transform_space = 'ORIGINAL'
    L.new(g["资产"], ci.inputs['Collection'])
    i3 = N.new('GeometryNodeInstanceOnPoints')
    L.new(sp.outputs[0], i3.inputs['Points']); L.new(ci.outputs[0], i3.inputs['Instance']); L.new(sc.outputs[0], i3.inputs['Scale'])
    neg = N.new('ShaderNodeVectorMath'); neg.operation = 'SCALE'; neg.inputs['Scale'].default_value = -1.0
    L.new(g["资产基点"], neg.inputs[0])
    tr = N.new('GeometryNodeTranslateInstances'); tr.inputs['Local Space'].default_value = True
    L.new(i3.outputs[0], tr.inputs['Instances']); L.new(neg.outputs[0], tr.inputs['Translation'])
    L.new(tr.outputs[0], go.inputs[0])
    b.layout()
    return ng


def socket_ids(ng):
    return {s.name: s.identifier for s in ng.interface.items_tree if s.in_out == 'INPUT'}


def get_params(ob, mod_name):
    m = ob.modifiers.get(mod_name)
    if not m:
        return None
    ids = socket_ids(m.node_group)
    return {k: m[i] for k, i in ids.items() if i in m}


def set_params(ob, mod_name, **kw):
    m = ob.modifiers[mod_name]
    ids = socket_ids(m.node_group)
    for k, v in kw.items():
        m[ids[k]] = v
    ob.update_tag()


def kind(ob):
    """'xyz' / 'point' / 'empty' / None"""
    if ob.type == 'EMPTY' and ob.instance_type == 'COLLECTION' and ob.instance_collection:
        return 'empty'
    if ob.type == 'MESH':
        if ob.modifiers.get(XYZ_MOD):
            return 'xyz'
        if ob.modifiers.get(POINT_MOD):
            return 'point'
    return None
