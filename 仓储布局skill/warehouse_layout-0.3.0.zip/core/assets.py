"""资产：链接、资产组、求值尺寸测量、类型分类。"""
import bpy
from mathutils import Vector

from . import prefs

GROUP_NAME = "GN资产组"
_CACHE = {}

DEFAULT_RULES = "guard:护栏;rail:轨道;hoist:提升机;stacker:堆垛机;rack:货架;pallet:托盘;conveyor:链式机,辊筒,顶升,输送,外形检测,扫描"
TYPE_LABEL = {"guard": "护栏", "rail": "轨道", "hoist": "提升机", "stacker": "堆垛机", "rack": "货架",
              "pallet": "托盘", "conveyor": "输送设备", "other": "其他"}


def _key(coll):
    return (coll.name, coll.library.filepath if coll.library else "")


def asset_info(coll):
    """求值测量资产：返回 dict(size, lo, hi, base, rep, rep_local)。
    链接集合里的对象不在场景中，matrix_world 未求值，直接读会错，所以用临时实例测量。"""
    k = _key(coll)
    if k in _CACHE:
        return _CACHE[k]
    tmp = bpy.data.objects.new("__wh_probe", None)
    tmp.instance_type = 'COLLECTION'
    tmp.instance_collection = coll
    bpy.context.scene.collection.objects.link(tmp)
    bpy.context.view_layer.update()
    dg = bpy.context.evaluated_depsgraph_get()
    lo = Vector((1e9,) * 3); hi = -lo
    mats = {}
    for inst in dg.object_instances:
        if inst.is_instance and inst.parent and inst.parent.original == tmp and inst.object.type in {'MESH', 'CURVE'}:
            mats.setdefault(inst.object.original.name_full, inst.matrix_world.copy())
            for v in inst.object.bound_box:
                w = inst.matrix_world @ Vector(v)
                lo = Vector(map(min, lo, w)); hi = Vector(map(max, hi, w))
    bpy.data.objects.remove(tmp)
    rep = sorted(mats)[0] if mats else None
    info = dict(size=tuple(hi - lo), lo=tuple(lo), hi=tuple(hi),
                base=((lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2, lo[2]),
                rep=rep, rep_local=mats.get(rep))
    _CACHE[k] = info
    return info


def clear_cache():
    _CACHE.clear()


def library_path():
    p = prefs()
    return bpy.path.abspath(p.asset_library) if p and p.asset_library else ""


def find_or_link(name, lib=None):
    c = next((c for c in bpy.data.collections if c.name == name and c.library), None) or bpy.data.collections.get(name)
    if c is None:
        lib = lib or library_path()
        if not lib:
            raise KeyError(f"场景中没有资产集合「{name}」，且未设置资产库路径")
        with bpy.data.libraries.load(lib, link=True) as (a, b):
            if name not in a.collections:
                raise KeyError(f"资产库中没有集合「{name}」")
            b.collections = [name]
        c = b.collections[0]
    return c


def ensure_asset_group(names, lib=None):
    """资产组：GN资产组 / NN_资产名(代理) / 资产集合。Collection Info 分离子项按名称排序，用序号前缀固定顺序。"""
    grp = bpy.data.collections.get(GROUP_NAME)
    if grp is None:
        grp = bpy.data.collections.new(GROUP_NAME)
        grp.use_fake_user = True
    idx = {}
    for p in grp.children:
        n, nm = p.name.split("_", 1)
        idx[nm] = int(n)
    for name in names:
        if name in idx:
            continue
        src = find_or_link(name, lib)
        i = max(idx.values(), default=-1) + 1
        proxy = bpy.data.collections.new(f"{i:02d}_{name}")
        proxy.children.link(src)
        grp.children.link(proxy)
        idx[name] = i
    return idx


def group_assets():
    """{idx: 资产集合}"""
    grp = bpy.data.collections.get(GROUP_NAME)
    out = {}
    if grp:
        for p in grp.children:
            n, _ = p.name.split("_", 1)
            if p.children:
                out[int(n)] = p.children[0]
    return out


def asset_collection(name):
    for c in group_assets().values():
        if c.name == name:
            return c
    return find_or_link(name)


def rules():
    p = prefs()
    s = p.type_rules if p and p.type_rules else DEFAULT_RULES
    out = []
    for part in s.split(";"):
        if ":" in part:
            t, kws = part.split(":", 1)
            out.append((t.strip(), [k.strip() for k in kws.split(",") if k.strip()]))
    return out


def classify(asset_name):
    for t, kws in rules():
        if any(k in asset_name for k in kws):
            return t
    return "other"


def referenced_assets():
    """场景里被实例化的资产集合：空对象实例、资产组、XYZ 阵列修改器。"""
    out = set()
    for o in bpy.data.objects:
        if o.instance_type == 'COLLECTION' and o.instance_collection:
            out.add(o.instance_collection)
        for m in o.modifiers:
            if m.type == 'NODES' and m.node_group:
                for s in m.node_group.interface.items_tree:
                    if s.in_out == 'INPUT' and s.socket_type == 'NodeSocketCollection':
                        c = m.get(s.identifier)
                        if c and c.name != GROUP_NAME:
                            out.add(c)
    out.update(group_assets().values())
    return out
