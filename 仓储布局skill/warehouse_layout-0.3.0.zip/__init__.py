bl_info = {
    "name": "仓储布局工具",
    "author": "long",
    "version": (0, 3, 0),
    "blender": (4, 2, 0),
    "location": "3D 视图 > N 面板 > 仓储布局",
    "description": "DXF 仓储布局：XYZ 几何节点阵列、一键转换、提升机/堆垛机高度对齐、验收报告",
    "category": "Object",
}

import bpy

from . import core, operators, ui

_classes = ui.classes + operators.classes


def register():
    core.ROOT_PACKAGE = __package__
    for c in _classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(_classes):
        bpy.utils.unregister_class(c)
