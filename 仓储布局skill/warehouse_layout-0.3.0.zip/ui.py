import bpy
from bpy.props import FloatProperty, StringProperty

from .core import nodes


class WH_Prefs(bpy.types.AddonPreferences):
    bl_idname = __package__
    asset_library: StringProperty(name="资产库 .blend", subtype='FILE_PATH', default="")
    hoist_margin: FloatProperty(name="提升机高出货架（默认）", default=1.0, unit='LENGTH')
    hoist_margin_min: FloatProperty(name="验收：提升机最少高出", default=0.3, unit='LENGTH')
    hoist_margin_max: FloatProperty(name="验收：提升机最多高出", default=2.0, unit='LENGTH')
    type_rules: StringProperty(
        name="类型规则", description="类型:关键词,关键词;... 按顺序匹配资产名",
        default="guard:护栏;rail:轨道;hoist:提升机;stacker:堆垛机;rack:货架;pallet:托盘;conveyor:链式机,辊筒,顶升,输送,外形检测,扫描")

    def draw(self, context):
        c = self.layout.column()
        c.prop(self, "asset_library")
        c.prop(self, "hoist_margin")
        r = c.row(); r.prop(self, "hoist_margin_min"); r.prop(self, "hoist_margin_max")
        c.prop(self, "type_rules")


class WH_PT_main(bpy.types.Panel):
    bl_label = "仓储布局"
    bl_idname = "WH_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "仓储布局"

    def draw(self, context):
        L = self.layout
        b = L.box(); b.label(text="平面底图", icon='IMAGE_REFERENCE')
        b.operator("wh.import_underlay")
        on = context.scene.get("wh_compare_on", False)
        b.operator("wh.compare_mode", text="退出对照模式" if on else "对照模式", depress=on)
        b.operator("wh.build_walls", icon='MOD_SOLIDIFY')
        b = L.box(); b.label(text="节点组", icon='NODETREE')
        b.operator("wh.setup_nodes")
        b = L.box(); b.label(text="转换（选中对象）", icon='MOD_ARRAY')
        op = b.operator("wh.to_xyz", text="转为 XYZ 阵列 · 按区块"); op.group_mode = 'CLUSTER'
        op = b.operator("wh.to_xyz", text="转为 XYZ 阵列 · 按排/列"); op.group_mode = 'LINE'
        b.operator("wh.to_points", text="转为点位对象 · 按输送线")
        b = L.box(); b.label(text="调整", icon='SORTSIZE')
        b.operator("wh.align_heights", text="提升机/堆垛机高度对齐")
        b = L.box(); b.label(text="验收", icon='CHECKMARK')
        b.operator("wh.validate")
        rep = context.scene.get("wh_last_report")
        if rep:
            for line in rep.splitlines()[:8]:
                b.label(text=line[:60])


class WH_PT_active(bpy.types.Panel):
    bl_label = "当前对象参数"
    bl_parent_id = "WH_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "仓储布局"

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and (nodes.kind(o) in ('xyz', 'point') or o.modifiers.get("墙体挤出") is not None)

    def draw(self, context):
        o = context.active_object
        mname = nodes.XYZ_MOD if nodes.kind(o) == 'xyz' else (nodes.POINT_MOD if nodes.kind(o) == 'point' else "墙体挤出")
        m = o.modifiers[mname]
        col = self.layout.column(align=True)
        for s in m.node_group.interface.items_tree:
            if s.in_out != 'INPUT' or s.socket_type in ('NodeSocketGeometry', 'NodeSocketCollection') or s.name in ("资产尺寸", "资产基点"):
                continue
            col.prop(m, f'["{s.identifier}"]', text=s.name)


classes = (WH_Prefs, WH_PT_main, WH_PT_active)
