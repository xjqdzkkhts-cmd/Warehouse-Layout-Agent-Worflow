# 仓储布局工具（Blender 4.2+）

## 这个插件做什么

DXF 仓储布局建模的执行层，负责下面几件事：
- 几何节点阵列；
- 一键转换；
- 提升机和堆垛机的高度对齐；
- 验收报告。

识图和语义确认交给 AI agent 或人工，这个插件只做确定性的执行和检查。

## 安装

编辑 → 偏好设置 → 获取扩展 → 右上角 ⌄ → **从磁盘安装…** → 选 `warehouse_layout-0.3.0.zip`。
在插件偏好里填好**资产库 .blend**，以及提升机高出货架的默认值（1.0m）。

## 面板（3D 视图 → N → 仓储布局）

| 按钮 | 作用 |
|---|---|
| 导入平面底图 | 对话框里有两个文件：<br>• **项目配置文件（project-config.json）**：必填。记录用哪张图纸、原点和单位、导入哪块区域；<br>• **替换图纸（可选）**：通常留空，只在图纸出了新版本、坐标没挪动时选新 DXF。<br>把平面图**按图层**导入为矢量线：<br>• 跨区域的大块（例如绑定进来的整栋建筑外部参照）会递归拆开，只取区域内的部分，所以墙、柱、门窗也能进底图；<br>• 外部参照图层名会去掉前缀，`AX-01-Plan.dwg-…$0$J-WALL` 显示为 `J-WALL`；<br>• 放在 z=−0.01，不可选中，颜色取 DXF 图层色；<br>• 解析结果缓存为 `.npz`，DXF 和配置没变时重导入约 0.1s；<br>• 插件自带 ezdxf，不依赖系统 Python |
| 一键挤出墙体 | 从底图的墙、门窗、柱图层自动识别墙段和空间（房间），生成：<br>• **每个空间一个墙体对象**，比如 `墙体_空间01`，带空间面积属性；外墙在隔墙接头处切段，归入各自的空间；<br>• 柱子一个对象；<br>• 墙体和柱子的高度、底标高都由几何节点「墙体挤出」控制，随时可以改；<br>• 复用底图缓存，生成不到 1 秒 |
| 对照模式 | 一键切到顶视正交视图，模型半透明，底图按图层着色；再点一次恢复原视图 |
| 注册节点组为资产 | 创建 `GN_XYZ阵列` 和 `GN_点位实例`，并标记为资产，可以在资产浏览器里拖用 |
| 转为 XYZ 阵列 · 按区块 / 按排列 | 把选中的集合实例空对象或点位对象自动分解成 X/Y/Z 阵列：<br>• 有缺口的地方自动分段；<br>• 背靠背的两列合成 Y=2；<br>• L 形区块拆成矩形；<br>• 同一区块或同一排的对象挂到同一个父级下。<br>实例数和包围盒一致才会替换，否则自动回滚 |
| 转为点位对象 · 按输送线 | 空对象转成点位 GN，按直线输送线自动分组，一条线里可以混合多种资产 |
| 提升机/堆垛机高度对齐 | 自动识别货架顶：提升机顶 = 货架顶 + 余量，堆垛机顶 = 货架顶 |
| 验收报告 | 按类型和资产计数，并检查五条规则：<br>• 提升机高于货架 0.3–2.0m；<br>• 堆垛机顶约等于货架顶；<br>• 堆垛机不与货架干涉；<br>• 每条巷道（轨道）恰好一台堆垛机；<br>• 护栏罩住轨道端部。<br>结果写入文本 `WH_验收报告`，面板上显示摘要 |
| 当前对象参数 | 选中阵列或点位对象时，直接显示 X/Y/Z 数量、间距等参数 |

资产类型按资产名里的关键词识别，规则可以在偏好设置里修改。默认规则：

```
guard:护栏; rail:轨道; hoist:提升机; stacker:堆垛机; rack:货架; pallet:托盘; conveyor:链式机,辊筒,顶升,输送,外形检测,扫描
```

## 底图配置（project-config.json）

```json
"dxf": "/…/图纸.dxf", "dxf_units": "mm", "origin_dxf_mm": [1660000, 110000],
"underlay": {
  "name": "1F",
  "region_dxf": [1650000, 1870000, 100000, 200000],
  "exclude_layers": ["2F补货线", "0-标高", "PUB_TEXT"],
  "include_text": false, "include_hatch": false, "flatten_m": 0.03, "z": -0.01
}
```

底图的原点和单位与模型共用同一套设置，所以两者一定对得上。

墙体配置（`walls` 段，可选）：

```json
"walls": {"height": 6.0, "wall_layers": ["J-WALL", "J-WALL-彩板墙体"], "opening_layers": ["J-WINDOW"],
          "column_layers": ["J-COLUMN", "砼柱"], "max_thickness": 0.8, "min_room_area": 3.0}
```

- 图层列表留空时，按名字自动识别：含 WALL/墙 的是墙，含 WIN/DOOR/门/窗 的是门窗，含 COLU/柱 的是柱。
- 门扇和门弧会把门洞封住，这样门两侧会分成两个空间。
- 窗段按墙处理（整墙高），不接触任何空间的窗框符号会被跳过。
- 区域和排除图层由 AI 在首次走查时写入，或者人工填写。
- 目前底图的线只在视口里显示，不参与渲染。需要出图时，可以对底图对象加线框修改器，或者用 Freestyle。

## 通过脚本或 Blender MCP 调用

每个操作器都会把结果写进 `scene["wh_last_result"]`（JSON）。验收报告还会写进 `scene["wh_last_report"]`。

```python
bpy.ops.wh.to_xyz(collection="G12_G13_横梁货架", prefix="横梁货架", group_mode='LINE')
bpy.ops.wh.to_points(collection="产线空对象", prefix="输送线", group_mode='LINE')
bpy.ops.wh.align_heights(margin=1.0)
bpy.ops.wh.validate(); print(bpy.context.scene["wh_last_report"])
bpy.ops.wh.import_underlay(config_path="/…/project-config.json")
bpy.ops.wh.compare_mode()
bpy.ops.wh.build_walls(config_path="/…/project-config.json", height=6.0)
```

## 测试

```bash
python3 tests/test_decompose.py
python3 tests/test_walls.py
WH_TEST_CONFIG=/…/project-config.json Blender -b 项目.blend --python tests/test_blender.py
```

后台回归测试只读、不保存。
